"""Cloud-provider, privacy-gating, export-format and extras tests. All hermetic: providers are faked on loopback."""
import http.client, io, json, os, stat, sys, tempfile, threading, unittest, zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from coverletter_ai import exporter as E, netguard
from coverletter_ai.cloud import CloudProvider, PROVIDERS
from coverletter_ai.config import Settings
from coverletter_ai.llm import ModelUnavailable
from coverletter_ai.parsing import extract_text
from coverletter_ai.service import App

RESUME = "# Test Person\ntest@example.com\n+91 98765 43210\n## Skills\nPython, SQL\n## Projects\nSales Dashboard\n- Built a dashboard tracking regional sales using SQL.\n"
JOB = "Data Analyst\nCompany: Acme\nRequirements:\n- Python and SQL\n- AWS mandatory\n"
SECRET = "sk-test-SECRET123456"
GOOD = "In my Sales Dashboard project, I built a dashboard tracking regional sales using SQL."
BAD = "I have extensive AWS experience and led a team of 15 at Google, increasing revenue by 40%."


class Fake(ThreadingHTTPServer):
    allow_reuse_address = True
    def __init__(self):
        self.reply, self.status, self.log = GOOD, 200, []
        outer = self
        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def _go(self):
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}")
                outer.log.append({"path": self.path, "headers": {k.lower(): v for k, v in self.headers.items()}, "body": body})
                if outer.status != 200:
                    self.send_response(outer.status); self.send_header("Retry-After", "0"); self.send_header("Content-Length", "2"); self.end_headers(); self.wfile.write(b"{}"); return
                p = self.path.split("?")[0]
                if p.endswith("/chat/completions"): out = {"choices": [{"message": {"content": outer.reply}}]}
                elif p.endswith(":generateContent"): out = {"candidates": [{"content": {"parts": [{"text": outer.reply}]}}]}
                elif p.endswith("/messages"): out = {"content": [{"type": "text", "text": outer.reply}]}
                elif p.endswith("/v1beta/models"): out = {"models": [{"name": "models/gem-flash", "supportedGenerationMethods": ["generateContent"]}, {"name": "models/embed", "supportedGenerationMethods": ["embedContent"]}]}
                elif p.endswith("/models"): out = {"data": [{"id": "a/free-one:free", "pricing": {"prompt": "0", "completion": "0"}}, {"id": "b/paid", "pricing": {"prompt": "0.1", "completion": "0.2"}}]}
                else: out = {}
                data = json.dumps(out).encode()
                self.send_response(200); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
            do_GET = do_POST = _go
        super().__init__(("127.0.0.1", 0), H)
        threading.Thread(target=self.serve_forever, daemon=True).start()
    @property
    def url(self): return f"http://127.0.0.1:{self.server_address[1]}"


def mk(offline=False):
    return App(Settings(data_dir=Path(tempfile.mkdtemp()), offline=offline))


def setup(app, fake, pid, base_suffix):
    app.registry[pid]["base"] = fake.url + base_suffix
    app.ai_set({"provider": pid, "key": SECRET, "model": "test-model", "consent": True})
    c = app.create_candidate(text=RESUME)["id"]
    j = app.analyze_job(c, JOB, company_description="Acme makes widgets.")["job_id"]
    return c, j


class CloudProviders(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.fake = Fake()
    @classmethod
    def tearDownClass(cls): cls.fake.shutdown()
    def setUp(self): self.fake.log.clear(); self.fake.status = 200; self.fake.reply = GOOD

    def test_openai_compatible_blocks_hallucinations_and_minimises_data(self):
        for pid in ("openai", "openrouter", "xai", "groq"):       # all share the OpenAI-compatible adapter
            self.fake.log.clear(); self.fake.reply = BAD + "\n\n" + GOOD
            a = mk(); c, j = setup(a, self.fake, pid, "/v1")
            r = a.generate(c, j)
            call = [x for x in self.fake.log if x["path"].endswith("/chat/completions")][0]
            self.assertEqual(call["headers"]["authorization"], "Bearer " + SECRET)
            self.assertNotIn(SECRET, call["path"])
            sent = json.dumps(call["body"])
            for private in ("test@example.com", "98765", "Test Person@"): self.assertNotIn(private, sent)  # contact data never leaves
            t = " ".join(r["paragraphs"]).lower()
            for bad in ("aws", "google", "40%", "led a team", "extensive"): self.assertNotIn(bad, t, pid)
            self.assertIn("sales dashboard", t)
            self.assertEqual(r["meta"]["engine"], "cloud"); self.assertEqual(r["report"]["unsupported_count"], 0)

    def test_gemini_uses_header_not_url(self):
        a = mk(); c, j = setup(a, self.fake, "gemini", "/v1beta")
        r = a.generate(c, j)
        call = [x for x in self.fake.log if x["path"].split("?")[0].endswith(":generateContent")][0]
        self.assertEqual(call["headers"]["x-goog-api-key"], SECRET); self.assertNotIn("key=", call["path"])
        self.assertIn("test-model", call["path"]); self.assertIn("sales dashboard", " ".join(r["paragraphs"]).lower())

    def test_anthropic_style(self):
        a = mk(); c, j = setup(a, self.fake, "anthropic", "/v1")
        r = a.generate(c, j)
        call = [x for x in self.fake.log if x["path"].endswith("/messages")][0]
        self.assertEqual(call["headers"]["x-api-key"], SECRET); self.assertIn("anthropic-version", call["headers"])
        self.assertIn("system", call["body"]); self.assertEqual(r["meta"]["engine"], "cloud")

    def test_list_models_and_free_filter(self):
        a = mk(); setup(a, self.fake, "openrouter", "/v1")
        self.assertEqual({m["id"] for m in a.ai_models("openrouter")}, {"a/free-one:free", "b/paid"})
        self.assertEqual([m["id"] for m in a.ai_models("openrouter", True)], ["a/free-one:free"])
        setup(a, self.fake, "gemini", "/v1beta")
        self.assertEqual([m["id"] for m in a.ai_models("gemini")], ["gem-flash"])
        self.assertTrue(a.ai_test("gemini")["ok"])

    def test_gating_offline_consent_key_model(self):
        a = mk(offline=True)                                   # real (remote) base URLs: nothing may be contacted
        netguard.blocked_attempts.clear()
        a.ai_set({"provider": "openai", "key": SECRET, "consent": True})
        self.assertIn("Network is off", a._resolve()[1]); self.assertEqual(a._resolve()[0].kind, a.local.kind)
        a.set_offline(False)
        a.ai_set({"provider": "openai", "consent": False}); self.assertIn("not approved", a._resolve()[1])
        a.ai_set({"provider": "openai", "consent": True, "remove_key": True}); self.assertIn("API key", a._resolve()[1])
        a.ai_set({"provider": "xai", "consent": True, "key": SECRET}); self.assertIn("model", a._resolve()[1])
        a.ai_set({"provider": "openai", "key": SECRET}); self.assertEqual(a._resolve()[0].kind, "cloud")
        self.assertEqual(netguard.blocked_attempts, [])
        a.set_offline(True)

    def test_offline_mode_generates_locally_with_note(self):
        a = mk(offline=True); c = a.create_candidate(text=RESUME)["id"]; j = a.analyze_job(c, JOB)["job_id"]
        a.ai_set({"provider": "openai", "key": SECRET, "consent": True, "model": "x"})
        r = a.generate(c, j)
        self.assertEqual(r["meta"]["engine"], "template"); self.assertTrue(any("Network is off" in n for n in r["meta"]["fallback_notes"]))
        a.ai_set({"provider": "openai", "fallback": False})
        self.assertIn("error", a.generate(c, j))                 # strict mode: no silent substitution
        a.set_offline(True)

    def test_errors_fall_back_to_local_visibly(self):
        a = mk(); c, j = setup(a, self.fake, "openai", "/v1")
        for status, word in ((401, "rejected the API key"), (429, "rate limit"), (402, "credits")):
            self.fake.status = status; a._cache.clear()
            r = a.generate(c, j, )
            self.assertEqual(r["meta"]["engine"], "template"); self.assertIn(word, " ".join(r["meta"]["fallback_notes"]).lower() if status != 401 else " ".join(r["meta"]["fallback_notes"]))
        with self.assertRaises(ModelUnavailable): CloudProvider("openai", PROVIDERS["openai"], SECRET, "m", timeout=1).__class__("openai", {**PROVIDERS["openai"], "base": "http://example.com/v1"}, SECRET, "m")

    def test_secrets_never_leak_and_file_is_private(self):
        a = mk(); setup(a, self.fake, "openai", "/v1")
        a.ai_set({"provider": "openai", "key": SECRET, "persist_key": True})
        blob = json.dumps([a.ai_status(), a.health(), a.audit_log(500)], ensure_ascii=False)
        self.assertNotIn("SECRET123456", blob); self.assertIn("••••3456", blob)
        self.assertEqual(stat.S_IMODE(os.stat(a.secrets.path).st_mode), 0o600)
        with self.assertRaises(Exception): a.ai_set({"provider": "openai", "key": "bad key\nX-Evil: 1"})
        a.delete_all(); self.assertFalse(a.secrets.path.exists())

    def test_preview_shows_exact_payload(self):
        a = mk(); c, j = setup(a, self.fake, "openai", "/v1")
        p = a.ai_preview(c, j)
        self.assertIn("Sales Dashboard", p["prompt"]); self.assertNotIn("test@example.com", p["prompt"]); self.assertIn("full resume", p["never_sent"])
        self.assertEqual(len(self.fake.log), 0)                  # preview makes no network call

    def test_cache_hit_and_force(self):
        a = mk(); c, j = setup(a, self.fake, "openai", "/v1")
        r1 = a.generate(c, j); n = len(self.fake.log)
        r2 = a.generate(c, j)
        self.assertTrue(r2["cache_hit"]); self.assertEqual(r2["letter_id"], r1["letter_id"]); self.assertEqual(len(self.fake.log), n)
        r3 = a.generate(c, j, {"force": True}); self.assertNotEqual(r3["letter_id"], r1["letter_id"]); self.assertGreater(len(self.fake.log), n)


class Exports(unittest.TestCase):
    C = {"header": {"name": "Zoë Müller", "contact": "z@example.com", "date": "1 Oct 2026", "company": "A&B <Co>", "role": "Data Analyst",
                    "greeting": "Dear Hiring Manager,", "signature": "Sincerely,"},
         "paragraphs": ["I built a dashboard {with} SQL \\ & more.", "Thank you for considering my application."]}

    def test_every_format(self):
        for f in E.FORMATS + ("zip",):
            data, mime, name = E.export(self.C, f); self.assertTrue(data and name.endswith("." + f), f)
        self.assertTrue(E.export(self.C, "pdf")[0].startswith(b"%PDF"))
        self.assertTrue(E.export(self.C, "rtf")[0].startswith(b"{\\rtf1"))
        self.assertIn(b"A&amp;B &lt;Co&gt;", E.export(self.C, "html")[0])
        self.assertEqual(json.loads(E.export(self.C, "json")[0])["header"]["role"], "Data Analyst")
        self.assertIn("Zoe_Muller", E.export(self.C, "txt")[2])
        with self.assertRaises(ValueError): E.export(self.C, "exe")

    def test_docx_odt_zip_structure(self):
        self.assertIn("Zoë Müller", extract_text("x.docx", E.export(self.C, "docx")[0])["text"])
        z = zipfile.ZipFile(io.BytesIO(E.export(self.C, "odt")[0]))
        self.assertEqual(z.namelist()[0], "mimetype"); self.assertEqual(z.getinfo("mimetype").compress_type, zipfile.ZIP_STORED)
        self.assertEqual(len(zipfile.ZipFile(io.BytesIO(E.export(self.C, "zip")[0])).namelist()), len(E.FORMATS))

    def test_pdf_fallback_without_reportlab(self):
        try: from pypdf import PdfReader
        except ImportError: self.skipTest("pypdf not installed")
        long = {**self.C, "paragraphs": ["Built dashboards with SQL. " * 80] * 3}
        r = PdfReader(io.BytesIO(E._pdf_fallback(long, "ats-minimal")))
        self.assertGreaterEqual(len(r.pages), 2); self.assertIn("Zoë", r.pages[0].extract_text())


class Extras(unittest.TestCase):
    def setUp(self):
        self.a = mk(offline=True); self.c = self.a.create_candidate(text=RESUME)["id"]
        self.j = self.a.analyze_job(self.c, JOB)["job_id"]

    def test_email_interview_variants(self):
        lid = self.a.generate(self.c, self.j)["letter_id"]
        e = self.a.email_draft(lid); self.assertIn("Data Analyst", e["subject"]); self.assertIn("Test Person", e["body"])
        qs = self.a.interview_prep(self.c, self.j)["questions"]
        self.assertTrue(any("AWS" in q["question"] and "gap" in q["basis"] for q in qs))
        v = self.a.variants(self.c, self.j); self.assertEqual([x["mode"] for x in v], ["formal", "standard", "technical"])
        self.assertTrue(all(x["report"]["unsupported_count"] == 0 for x in v))

    def test_batch_and_zip(self):
        out = self.a.batch(self.c, [{"text": JOB}, {"text": "Analyst\nRequirements:\n- SQL\n", "company": "Beta"}, {"text": ""}])["results"]
        self.assertEqual([r["status"] for r in out][:2], ["Passed", "Passed"]); self.assertEqual(out[2]["status"], "error")
        z = zipfile.ZipFile(io.BytesIO(self.a.batch_zip([r["letter_id"] for r in out[:2]], ("pdf", "docx", "txt"))))
        self.assertEqual(len(z.namelist()), 6)

    def test_http_keepalive_and_token_and_text_convert(self):
        from coverletter_ai.server import make_server
        import base64
        a = App(Settings(data_dir=Path(tempfile.mkdtemp()), offline=True, token="tok"))
        srv = make_server(a, "127.0.0.1", 0); threading.Thread(target=srv.serve_forever, daemon=True).start()
        conn = http.client.HTTPConnection("127.0.0.1", srv.server_address[1])
        def call(method, path, body=None, auth=True):
            h = {"Content-Type": "application/json", **({"Authorization": "Bearer tok"} if auth else {})}
            conn.request(method, path, json.dumps(body) if body is not None else None, h); r = conn.getresponse(); return r.status, json.loads(r.read())
        self.assertEqual(call("POST", "/api/convert/text", {"filename": "a.txt", "content_b64": "eA=="}, auth=False)[0], 401)  # body drained, same socket reused
        s, d = call("POST", "/api/convert/text", {"filename": "r.md", "content_b64": base64.b64encode(RESUME.encode()).decode()})
        self.assertEqual(s, 200); self.assertIn("Sales Dashboard", d["text"])
        s, d = call("GET", "/api/ai"); self.assertEqual(s, 200); self.assertNotIn('"key":', json.dumps(d)); self.assertNotIn("tok", json.dumps(d).replace("token", ""))
        self.assertEqual(call("POST", "/api/ai", {"provider": "nope"})[0], 400)
        srv.shutdown()


if __name__ == "__main__":
    unittest.main()
