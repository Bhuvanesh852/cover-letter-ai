"""AI-engine settings, hybrid (cloud/local) provider resolution, caching and productivity extras."""
import copy
import hashlib
import json
from . import knowledge as K
from .cloud import CloudProvider, is_loopback
from .evidence import build_evidence, select_evidence_chunks
from .exporter import export_many
from .generator import SYSTEM_RULES, build_prompt
from .errors import BadRequest
from .llm import ModelUnavailable

DEFAULT_AI = {"provider": "local", "models": {}, "consent": {}, "fallback": True}


class AIMixin:
    # ---------- configuration ----------
    def _ai(self) -> dict:
        r = self.db.one("SELECT value FROM settings WHERE key='ai'")
        return {**copy.deepcopy(DEFAULT_AI), **(json.loads(r["value"]) if r else {})}

    def _ai_save(self, ai):
        self.db.x("INSERT OR REPLACE INTO settings VALUES('ai',?)", (json.dumps(ai),))

    def _spec(self, pid):
        if pid not in self.registry: raise BadRequest("Unknown provider.")
        return self.registry[pid]

    def ai_status(self) -> dict:
        ai, rows = self._ai(), []
        for pid, sp in self.registry.items():
            info = self.secrets.info(pid, sp["env"])
            remote = not is_loopback(sp["base"])
            rows.append({"id": pid, "label": sp["label"], "model": ai["models"].get(pid) or sp["model"],
                         "consent": bool(ai["consent"].get(pid)), "needs_network": remote, "key_optional": bool(sp.get("key_optional")),
                         "free_note": sp["free"], "key_url": sp.get("key_url", ""), "supports_free_filter": bool(sp.get("free_filter")), **info})
        prov, reason = self._resolve()
        return {"selected": ai["provider"], "fallback": ai["fallback"], "providers": rows,
                "effective": {"kind": prov.kind if prov else "none", "name": prov.name if prov else "", "reason": reason},
                "local": {"kind": self.local.kind, "name": self.local.name}}

    def ai_set(self, d: dict) -> dict:
        ai, pid = self._ai(), d.get("provider", "local")
        if pid != "local":
            self._spec(pid)
            if d.get("remove_key"): self.secrets.delete(pid)
            if d.get("key"):
                try: self.secrets.set(pid, d["key"], bool(d.get("persist_key")))
                except ValueError as e: raise BadRequest(str(e))
            if "model" in d: ai["models"][pid] = str(d["model"]).strip()[:120]
            if "consent" in d: ai["consent"][pid] = bool(d["consent"])
            if d.get("base_url") is not None and pid == "custom":
                b = str(d["base_url"]).strip().rstrip("/")
                if not (b.startswith("https://") or is_loopback(b)): raise BadRequest("Custom servers must use https (or a loopback address).")
                self.registry["custom"]["base"] = b; ai["custom_base"] = b
        if "fallback" in d: ai["fallback"] = bool(d["fallback"])
        if d.get("activate", True): ai["provider"] = pid
        self._ai_save(ai)
        self.db.audit("ai_config", {"provider": pid, "consent": ai["consent"].get(pid), "has_key": self.secrets.info(pid, self.registry[pid]["env"])["has_key"] if pid != "local" else None})
        return self.ai_status()

    def _cloud(self, pid, ai=None) -> CloudProvider:
        ai, sp = ai or self._ai(), self._spec(pid)
        key, _ = self.secrets.get(pid, sp["env"])
        return CloudProvider(pid, sp, key, ai["models"].get(pid) or sp["model"], self.s.temperature, self.s.top_p)

    def _resolve(self):
        """-> (provider|None, reason). Cloud needs: online + consent + key + model. Otherwise local (if fallback on)."""
        ai, sel = self._ai(), self._ai()["provider"]
        if sel == "local" or sel not in self.registry: return self.local, None
        sp, reason = self.registry[sel], None
        key, _ = self.secrets.get(sel, sp["env"])
        remote = not is_loopback(sp["base"])
        if remote and self.s.offline: reason = "Network is off (offline mode)"
        elif remote and not ai["consent"].get(sel): reason = f"{sp['label']} is not approved for use"
        elif not key and not sp.get("key_optional"): reason = f"No {sp['label']} API key"
        elif not (ai["models"].get(sel) or sp["model"]): reason = "No model selected"
        if reason: return (self.local if ai["fallback"] else None), reason
        return self._cloud(sel, ai), None

    def ai_models(self, pid, free_only=False):
        sp = self._spec(pid)
        if not is_loopback(sp["base"]) and self.s.offline: raise BadRequest("Network is off. Turn offline mode off to list provider models.")
        key, _ = self.secrets.get(pid, sp["env"])
        if not key and not sp.get("key_optional"): raise BadRequest("Add an API key first.")
        try: return CloudProvider(pid, sp, key, "", ).list_models(free_only)
        except ModelUnavailable as e: raise BadRequest(str(e))

    def ai_test(self, pid) -> dict:
        if pid == "local":
            self.local = self._pick_local(); return {"ok": True, **self.local.health_check(), "kind": self.local.kind}
        sp = self._spec(pid)
        if not is_loopback(sp["base"]) and self.s.offline: return {"ok": False, "error": "Network is off (offline mode)."}
        key, _ = self.secrets.get(pid, sp["env"])
        if not key and not sp.get("key_optional"): return {"ok": False, "error": "No API key saved."}
        return CloudProvider(pid, sp, key, self._ai()["models"].get(pid) or sp["model"]).health_check()  # lists models: no tokens spent

    def ai_preview(self, cid, jid, opts=None) -> dict:
        """Exactly what would leave this machine for the selected cloud provider."""
        opts = {"mode": "standard", "length": 300, **(opts or {})}
        cand, job = self._cand(cid), self._job(jid)
        ev = build_evidence(self.rag, cand, job, job["company_info"])
        picks = select_evidence_chunks(self.rag, cid, job, ev["pack"], 3)
        prompt = build_prompt(cand["profile"], job, ev["pack"], picks, job["company_info"], opts)
        prov, reason = self._resolve()
        return {"destination": getattr(prov, "pid", "local (this machine)"), "reason": reason, "system": SYSTEM_RULES, "prompt": prompt,
                "sent": ["your name", "selected resume evidence snippets", "skills list", "job title/requirements/responsibilities", "company text you provided"],
                "never_sent": ["full resume", "email", "phone", "links", "other profiles", "API keys of other providers"]}

    # ---------- hybrid generation + cache ----------
    def _cache_key(self, cand, job, ev, opts, prov):
        raw = json.dumps([ev["pack"]["evidence_hash"], job["desc_hash"], job["company_info"]["description"], opts, prov.name, prov.kind, self.s.prompt_version], sort_keys=True)
        return hashlib.sha256(raw.encode()).hexdigest()

    def generate(self, cid, jid, opts=None):
        opts = {"mode": "standard", "length": 300, **(opts or {})}
        if opts["mode"] not in ("standard", "fresher", "technical", "formal"): raise BadRequest("Unknown mode.")
        opts["length"] = max(120, min(int(opts["length"]), 600))
        force = bool(opts.pop("force", False))
        cand, job = self._cand(cid), self._job(jid)
        ev = build_evidence(self.rag, cand, job, job["company_info"])
        prov, reason = self._resolve()
        if prov is None:
            return {"error": f"Cloud engine unavailable: {reason}.", "actions": ["Open AI settings", "Switch to local engine", "Turn on local fallback"]}
        key = self._cache_key(cand, job, ev, opts, prov)
        if not force and key in self._cache and self.db.one("SELECT id FROM letters WHERE id=?", (self._cache[key],)):
            L = self.get_letter(self._cache[key])
            return {"letter_id": L["id"], "header": L["content"]["header"], "paragraphs": L["content"]["paragraphs"], "report": L["validation"]["report"],
                    "style": L["validation"]["style"], "meta": L["meta"], "evidence": ev, "grounding": L["validation"]["report"]["status"],
                    "trace": [{"state": "CACHE_HIT", "ts": ""}], "cache_hit": True}
        from .generator import Generator
        res, notes = Generator(self.rag, prov).run(cand, job, job["company_info"], ev["pack"], opts, self.s.prompt_version), []
        if reason: notes.append(f"{reason}; used the local engine")
        if "error" in res and prov.kind == "cloud":
            err = res["error"]
            if self._ai()["fallback"]:
                notes.append(f"{err} Used the local engine instead."); prov = self.local
                res = Generator(self.rag, prov).run(cand, job, job["company_info"], ev["pack"], opts, self.s.prompt_version)
        if "error" in res:
            self.db.audit("generation_failed", {"job": jid}); return res
        res["meta"].update(options=opts, engine=prov.kind, fallback_notes=notes)
        lid = self._save_letter(cid, jid, {"header": res["header"], "paragraphs": res["paragraphs"]}, res["report"], res["style"], res["meta"])
        self._cache[key] = lid
        while len(self._cache) > 64: self._cache.pop(next(iter(self._cache)))
        self.db.audit("generation", {"job": jid, "letter": lid, "engine": prov.kind, "validation": res["report"]["status"], "unsupported": res["report"]["unsupported_count"]}, network=prov.kind == "cloud")
        res.update(letter_id=lid, evidence=ev, grounding=res["report"]["status"], notes=notes, cache_hit=False)
        return res

    # ---------- extras ----------
    def variants(self, cid, jid, opts=None):
        return [{"mode": m, **self.generate(cid, jid, {**(opts or {}), "mode": m})} for m in ("formal", "standard", "technical")]

    def batch(self, cid, jobs: list, opts=None) -> dict:
        if not jobs or len(jobs) > 25: raise BadRequest("Provide between 1 and 25 jobs.")
        out = []
        for j in jobs:
            try:
                a = self.analyze_job(cid, j.get("text", ""), j.get("title", ""), j.get("company", ""), j.get("company_description", ""))
                g = self.generate(cid, a["job_id"], opts)
                out.append({"job_id": a["job_id"], "title": a["job"]["title"], "company": a["job"]["company"], "letter_id": g.get("letter_id"),
                            "status": g.get("grounding", "error"), "error": g.get("error")})
            except Exception as e:  # one bad job must not abort the batch
                out.append({"title": j.get("title", ""), "company": j.get("company", ""), "status": "error", "error": str(e)})
        return {"results": out}

    def batch_zip(self, letter_ids: list, fmts=("pdf", "docx", "txt"), template="ats-minimal") -> bytes:
        return export_many([self.get_letter(i)["content"] for i in letter_ids], template, tuple(fmts))

    def email_draft(self, lid) -> dict:
        h = self.get_letter(lid)["content"]["header"]
        at = f" at {h['company']}" if h["company"] else ""
        body = (f"{h['greeting']}\n\nPlease find attached my application for the {h['role']} position{at}. "
                f"My cover letter is attached for your consideration, and I would be glad to share further details.\n\n"
                f"Thank you for your time.\n\nBest regards,\n{h['name']}\n{h['contact']}")
        return {"subject": f"Application for {h['role']} - {h['name']}", "body": body}

    def interview_prep(self, cid, jid) -> dict:
        cand, job = self._cand(cid), self._job(jid)
        ev, qs = build_evidence(self.rag, cand, job, job["company_info"]), []
        for m in ev["matrix"]:
            r = m["requirement"]
            if m["kind"] == "responsibility":
                qs.append({"question": f"How would you approach this part of the role: {r}?", "basis": "job responsibility", "evidence": [e["subsection"] for e in m["evidence"]]})
            elif m["level"] == "strong":
                sub = m["evidence"][0]["subsection"] if m["evidence"] else "your work"
                qs.append({"question": f"Tell me about {sub} and how you used {r}.", "basis": "strong evidence", "evidence": [e["subsection"] for e in m["evidence"]]})
            elif m["level"] == "partial":
                qs.append({"question": f"{r} is on your resume. Describe a situation where you used it.", "basis": "listed skill - prepare an example", "evidence": []})
            elif m["kind"] == "required":
                qs.append({"question": f"This role uses {r}, which is not on your resume. How would you get up to speed?", "basis": "gap - answer honestly", "evidence": []})
        return {"questions": qs[:12], "note": "Prepare real examples. Questions marked 'gap' are areas to be honest about."}

    # ---------- "Claude (or any external model) writes, the app verifies" ----------
    def evidence_for_writer(self, cid, jid, length=300) -> dict:
        """Everything an external writer may use - and nothing else. Contact details are deliberately excluded."""
        cand, job = self._cand(cid), self._job(jid)
        ev = build_evidence(self.rag, cand, job, job["company_info"])
        n = 2 if length <= 250 else 3 if length <= 350 else 4
        picks = select_evidence_chunks(self.rag, cid, job, ev["pack"], n)
        p = ev["pack"]
        return {"candidate_name": cand["profile"].get("name", ""), "target_role": job["title"], "company": job.get("company", ""),
                "evidence_snippets": [{"section": c["section"], "title": c["subsection"], "text": c["text"]} for c, _ in picks],
                "strong_matches": [m["requirement"] for m in p["strong_matches"]], "partial_matches": [m["requirement"] for m in p["partial_matches"]],
                "missing_requirements": p["missing_requirements"], "allowed_skills": [K.display(s) for s in p["allowed_skills"]],
                "prohibited_claims": p["prohibited_claims"], "company_context": p["company_context"],
                "required_skills": [K.display(s) for s in job["required_skills"]], "responsibilities": job["responsibilities"][:5],
                "target_words": length, "rules": SYSTEM_RULES}

    def import_letter(self, cid, jid, text: str, sanitize=True, source="external") -> dict:
        """Validate a letter written elsewhere. Unsupported sentences are removed by default (never shipped)."""
        import re
        from .generator import header_for
        from .validator import style_report
        cand, job = self._cand(cid), self._job(jid)
        if not text or not text.strip(): raise BadRequest("Provide the letter text.")
        lines, keep = text.strip().splitlines(), []
        for ln in lines:
            if re.match(r"^\s*(sincerely|kind regards|best regards|regards|yours (sincerely|faithfully))\b", ln, re.I): break
            if re.match(r"^\s*(dear\b|re:|subject:)", ln, re.I): continue
            keep.append(ln)
        paras = [re.sub(r"\s+", " ", p).strip() for p in re.split(r"\n\s*\n", "\n".join(keep)) if p.strip()]
        name = cand["profile"].get("name", "")
        paras = [p for p in paras if p != name]
        v, _ = self._validator(cid, jid)
        report, removed = v.check(paras), []
        if sanitize and report["unsupported_count"]:
            removed = [{"text": s["text"], "issues": s["issues"]} for ss in report["paragraphs"] for s in ss if s["label"] == "UNSUPPORTED"]
            paras = v.sanitize(report); report = v.check(paras)
        if not paras: raise BadRequest("Every sentence was unsupported by the profile, so nothing could be saved. Use get_evidence_pack and write from it.")
        style = style_report(paras, report, job)
        ev = build_evidence(self.rag, cand, job, job["company_info"])
        meta = {"model": f"{source} writer", "model_kind": "external", "engine": "external", "prompt_version": "n/a", "mode": "external",
                "evidence_hash": ev["pack"]["evidence_hash"], "fallback_notes": [], "removed_unsupported": len(removed)}
        content = {"header": header_for(cand["profile"], job, job.get("company", ""), {}), "paragraphs": paras}
        lid = self._save_letter(cid, jid, content, report, style, meta)
        self.db.audit("letter_imported", {"letter": lid, "source": source, "removed": len(removed), "validation": report["status"]})
        return {"letter_id": lid, "content": content, "report": report, "style": style, "removed": removed}
