"""Claim-control engine: every sentence is VERIFIED / SUPPORTED_INFERENCE / GENERAL_PROFESSIONAL_LANGUAGE / UNSUPPORTED.
Policy: Truth > Personalization > Style. Unsupported sentences are removed, never 'polished'."""
import re
from . import knowledge as K

VERIFIED, INFERENCE, GENERAL, UNSUPPORTED = "VERIFIED", "SUPPORTED_INFERENCE", "GENERAL_PROFESSIONAL_LANGUAGE", "UNSUPPORTED"
GENERIC = re.compile(r"^(i am|i'm) (writing|applying|excited|keen|eager|pleased|delighted) |thank you for|would welcome the opportunity|"
                     r"look forward to|^dear |^sincerely|^kind regards|^best regards", re.I)
GROWTH = re.compile(r"\b(keen to|eager to|looking to|hope to|want to|interested in|happy to|ready to|excited to)\b.*\b(learn|develop|build|grow|gain|deepen)", re.I)
INFLATED = re.compile(r"\b(extensive(ly)?|expert(ise)?|proven track record|seasoned|world-class|award-winning|results-driven|"
                      r"highly experienced|deep experience|decade|passionate|thrilled)\b", re.I)
LEAD = re.compile(r"\b(led|lead|leading|managed|manage|directed|headed|supervised|mentored|founded|spearheaded|oversaw|"
                  r"senior|principal|architected)\b", re.I)
YEARS = re.compile(r"\b(\d+|one|two|three|four|five|six|seven|eight|nine|ten|several|many|multiple|numerous)\+?\s*(years?|yrs?)\b|"
                   r"\byears of (professional |hands-on )?experience\b", re.I)
NUM = re.compile(r"\b\d[\d,.]*\+?%?")
COMPANY_CLAIM = re.compile(r"\b(leading|leader|largest|global|world-class|renowned|award|innovative|pioneer|market leader|"
                           r"fastest|top-tier|industry-leading|founded|headquartered|funded|acquired|billion|million)\b", re.I)
COMMON_CAPS = {"i", "i'm", "i've", "i'd", "i'll", "english", "monday", "tuesday", "wednesday", "thursday", "friday"}


def _norm(s): return re.sub(r"[\s,]", "", s.lower())


class Validator:
    def __init__(self, chunks: list, allowed_skills: set, company_text: str = "", company_name: str = "",
                 extra_vocab: str = "", candidate_name: str = ""):
        self.chunks = chunks
        self.allowed = set(allowed_skills)
        self.cand_text = " ".join(f"{c['section']} {c['subsection']} {c['text']}" for c in chunks) + " " + candidate_name
        self.company_text, self.company_name = company_text or "", company_name or ""
        self.vocab = set(K.words(self.cand_text + " " + self.company_text + " " + company_name + " " + extra_vocab))
        self.vocab |= {w.strip(".") for w in self.vocab}
        self.cstems = [(c, K.content_stems(f"{c['section']} {c['subsection']} {c['text']}")) for c in chunks]
        self.company_stems = K.content_stems(self.company_text)
        self.cand_norm = _norm(self.cand_text)
        self.all_norm = self.cand_norm + _norm(self.company_text)

    def _best_chunk(self, st):
        best, score = None, 0.0
        for c, cs in self.cstems:
            o = len(st & cs) / len(st) if st else 0
            if o > score:
                best, score = c, o
        return best, score

    def check_sentence(self, s: str) -> dict:
        st = K.content_stems(s)
        issues = []
        comp_overlap = len(st & self.company_stems) / len(st) if st and self.company_stems else 0
        chunk, overlap = self._best_chunk(st)
        company_sourced = comp_overlap >= 0.6 and comp_overlap > overlap
        if not company_sourced:
            for canon in K.find_skills(s):
                if canon not in self.allowed and not GROWTH.search(s):
                    issues.append(f"'{K.display(canon)}' is not evidenced in the candidate profile")
            for m in NUM.finditer(s):
                tok = m.group(0).rstrip(".,")
                if _norm(tok) not in self.all_norm:
                    issues.append(f"number '{tok}' does not appear in any source")
            for w in s.split()[1:]:
                t = w.strip(".,;:!?()\"'")
                if t[:1].isupper() and t.lower() not in COMMON_CAPS and t.lower() not in self.vocab and not K.find_skills(t):
                    issues.append(f"unrecognised name '{t}' is not in any source")
        if YEARS.search(s) and not YEARS.search(self.cand_text):
            issues.append("experience duration is not stated in the profile")
        for rx, label in ((INFLATED, "inflated wording"), (LEAD, "leadership/seniority claim")):
            for m in rx.finditer(s):
                if m.group(0).lower() not in self.cand_text.lower():
                    issues.append(f"{label} '{m.group(0)}' is not supported")
        for m in COMPANY_CLAIM.finditer(s):
            w = m.group(0).lower()
            if w not in self.company_text.lower() and w not in self.cand_text.lower():
                issues.append(f"company claim '{m.group(0)}' has no source")
        issues = list(dict.fromkeys(issues))
        src = None
        if issues:
            label = UNSUPPORTED
        elif company_sourced:
            label, src = VERIFIED, {"type": "company", "source_label": "USER PROVIDED"}
        elif overlap >= 0.55 and chunk:
            label = VERIFIED
        elif GROWTH.search(s) or (GENERIC.search(s) and not K.find_skills(s)):
            label = GENERAL
        elif K.find_skills(s) or overlap >= 0.3:
            label = INFERENCE
        else:
            label = GENERAL
        if chunk and label in (VERIFIED, INFERENCE) and not src:
            src = {"type": "candidate", "chunk_id": chunk["id"], "section": chunk["section"],
                   "subsection": chunk["subsection"], "source_type": chunk["source_type"], "status": chunk["fact_status"]}
        return {"text": s, "label": label, "issues": issues, "source": src, "overlap": round(overlap, 2)}

    def check(self, paragraphs: list) -> dict:
        paras, flat = [], []
        for p in paragraphs:
            ss = [self.check_sentence(s) for s in K.sentences(p)]
            paras.append(ss)
            flat += ss
        n = len(flat) or 1
        unsupported = sum(1 for s in flat if s["label"] == UNSUPPORTED)
        grounded = sum(1 for s in flat if s["label"] in (VERIFIED, INFERENCE))
        return {"paragraphs": paras, "unsupported_count": unsupported,
                "grounded_claim_ratio": round(grounded / n, 2),
                "status": "Passed" if unsupported == 0 else "Needs review"}

    @staticmethod
    def sanitize(report: dict) -> list:
        """Remove unsupported sentences; drop emptied paragraphs."""
        out = []
        for ss in report["paragraphs"]:
            kept = " ".join(s["text"] for s in ss if s["label"] != UNSUPPORTED)
            if kept.strip():
                out.append(kept)
        return out


CLICHES = [r"highly motivated individual", r"thrilled to leverage", r"extensive expertise", r"\bpassionate\b",
           r"\bdynamic\b", r"team player", r"go-getter", r"think outside the box", r"hit the ground running"]


def style_report(paragraphs: list, report: dict, job: dict) -> dict:
    text = "\n".join(paragraphs)
    w = K.words(text)
    tri = [tuple(w[i:i + 3]) for i in range(len(w) - 2)]
    rep = 1 - len(set(tri)) / len(tri) if tri else 0
    flat = [s for ss in report["paragraphs"] for s in ss]
    req = [K.display(c) for c in job["required_skills"]]
    present = [r for r in req if r.lower() in text.lower()]
    return {
        "word_count": len(text.split()),
        "cliches": [c for c in CLICHES if re.search(c, text, re.I)],
        "repetition_ratio": round(rep, 2),
        "generic_sentence_ratio": round(sum(1 for s in flat if s["label"] == GENERAL) / (len(flat) or 1), 2),
        "ats": {"role_title_present": bool(job["title"]) and job["title"].lower() in text.lower(),
                "required_keywords_in_letter": present, "required_keywords_total": len(req)},
    }
