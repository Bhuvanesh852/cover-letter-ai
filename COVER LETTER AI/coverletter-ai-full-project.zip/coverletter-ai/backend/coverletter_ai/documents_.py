from .parsing import extract_text, ParseError  # noqa: F401
def parse_upload(filename, data, max_mb=20):
    return extract_text(filename, data, max_mb)
