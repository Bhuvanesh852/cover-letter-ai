"""CoverLetter AI - offline-first, evidence-grounded cover letter engine."""
__version__ = "1.0.0"
