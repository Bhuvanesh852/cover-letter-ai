"""Evidence matrix + evidence pack (the only facts the generator may use)."""
import hashlib
import json
from . import knowledge as K


def candidate_skill_sets(chunks: list) -> tuple:
    """(demonstrated, listed): demonstrated = appears in projects/experience/certs/etc; listed = skills list only."""
    demo, listed = {}, {}
    for c in chunks:
        hits = K.find_skills(c["text"] + " " + c["subsection"])
        for s in hits:
            (listed if c["section"] == "skills" else demo).setdefault(s, []).append(c)
    return demo, listed


def build_evidence(rag, candidate: dict, job: dict, company: dict = None) -> dict:
    chunks = rag.active_chunks(candidate["id"])
    demo, listed = candidate_skill_sets(chunks)
    matrix = []
    reqs = [(s, "required") for s in job["required_skills"]] + [(s, "preferred") for s in job["preferred_skills"]]
    for s, kind in reqs:
        if s in demo:
            level, ev = "strong", demo[s]
        elif s in listed:
            level, ev = "partial", listed[s]
        else:
            level, ev = "missing", []
        matrix.append({"requirement": K.display(s), "canon": s, "kind": kind, "level": level,
                       "evidence": [{"chunk_id": c["id"], "section": c["section"], "subsection": c["subsection"],
                                     "source": c["source_type"]} for c in ev[:3]],
                       "note": ("Not found in current profile. Add it only if you genuinely have this experience."
                                if level == "missing" else "")})
    for line in job.get("responsibilities", [])[:6]:
        hit = rag.search(candidate["id"], line, k=1)
        ok = bool(hit) and hit[0]["score"] >= 0.45
        matrix.append({"requirement": line[:90], "canon": None, "kind": "responsibility",
                       "level": "partial" if ok else "missing",
                       "evidence": [{"chunk_id": hit[0]["chunk_id"], "section": hit[0]["section"],
                                     "subsection": hit[0]["subsection"], "source": hit[0]["source_type"]}] if ok else [],
                       "note": "Related evidence found (similarity only)." if ok else ""})
    skill_rows = [m for m in matrix if m["canon"]]
    covered = [m for m in skill_rows if m["level"] != "missing"]
    all_skills = set(demo) | set(listed)
    company = company or {}
    pack = {
        "candidate_name": candidate["name"], "target_role": job["title"], "company_name": job.get("company", ""),
        "strong_matches": [m for m in skill_rows if m["level"] == "strong"],
        "partial_matches": [m for m in skill_rows if m["level"] == "partial"],
        "missing_requirements": [m["requirement"] for m in skill_rows if m["level"] == "missing"],
        "company_context": ([{"text": company["description"], "source_label": company.get("source_label", "USER PROVIDED")}]
                            if company.get("description") else []),
        "allowed_skills": sorted(all_skills),
        "prohibited_claims": [f"experience with {K.display(m['canon'])}" for m in skill_rows if m["level"] == "missing"],
        "alignment": {  # informational only - never a hiring prediction
            "requirement_coverage": f"{len(covered)}/{len(skill_rows)}" if skill_rows else "n/a",
            "evidence_coverage": f"{sum(1 for m in skill_rows if m['level']=='strong')}/{len(skill_rows)}" if skill_rows else "n/a",
        },
    }
    pack["evidence_hash"] = hashlib.sha256(json.dumps(
        [pack["strong_matches"], pack["partial_matches"], pack["company_context"]], sort_keys=True).encode()).hexdigest()[:16]
    return {"matrix": matrix, "pack": pack}


def select_evidence_chunks(rag, candidate_id: str, job: dict, pack: dict, n: int) -> list:
    """Rank demonstrating chunks by job-skill hits (required x2), specificity, and diversity."""
    chunks = [c for c in rag.active_chunks(candidate_id) if c["section"] in ("projects", "experience", "achievements")]
    w = {s: 2 for s in job["required_skills"]} | {s: 1 for s in job["preferred_skills"]}
    scored = []
    for c in chunks:
        hits = set(K.find_skills(c["text"] + " " + c["subsection"])) & set(w)
        score = sum(w[h] for h in hits) + (0.5 if any(ch.isdigit() for ch in c["text"]) else 0) + min(len(c["text"]), 300) / 600
        if hits:
            scored.append((score, c, hits))
    scored.sort(key=lambda t: -t[0])
    picked, covered = [], set()
    for score, c, hits in scored:
        if len(picked) >= n:
            break
        if hits - covered or len(picked) < 1:
            picked.append((c, hits))
            covered |= hits
    if len(picked) < n:  # fill with the next most relevant project/experience items (still real evidence)
        q = job["title"] + " " + " ".join(job.get("responsibilities", []))
        have = {c["id"] for c, _ in picked}
        by_id = {c["id"]: c for c in chunks}
        for r in rag.search(candidate_id, q, k=10, sections=("projects", "experience")):
            if len(picked) >= n: break
            if r["chunk_id"] not in have and r["chunk_id"] in by_id:
                picked.append((by_id[r["chunk_id"]], set(K.find_skills(r["text"]))))
    return picked
