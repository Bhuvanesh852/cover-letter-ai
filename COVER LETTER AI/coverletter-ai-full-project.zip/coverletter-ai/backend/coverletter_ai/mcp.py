"""Connector registry + tool router with permissions (DENY/ASK/ALLOW), network kill switch, schema validation, audit.
The model never picks tools or sees secrets; the application calls the router with minimised arguments."""
import ipaddress
import re
import socket
import urllib.request
from html.parser import HTMLParser
from urllib.parse import urlparse
from . import jobs
from .db import now


class ToolError(Exception):
    pass


class NetworkDisabled(ToolError):
    pass


class _Readable(HTMLParser):
    """Text extractor that drops scripts, navigation, forms and any hidden element (with correct nesting)."""
    SKIP = {"script", "style", "noscript", "nav", "header", "footer", "form", "svg", "iframe", "template", "aside"}
    VOID = {"br", "img", "input", "meta", "link", "hr"}

    def __init__(self):
        super().__init__(); self.skip_tag, self.skip_depth, self.out, self.title, self._t = None, 0, [], "", False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if self.skip_tag:
            if tag == self.skip_tag: self.skip_depth += 1
            return
        hidden = "hidden" in a or "display:none" in (a.get("style") or "").replace(" ", "").lower()
        if (tag in self.SKIP or hidden) and tag not in self.VOID:
            self.skip_tag, self.skip_depth = tag, 1
        elif tag == "title":
            self._t = True

    def handle_endtag(self, tag):
        if self.skip_tag and tag == self.skip_tag:
            self.skip_depth -= 1
            if self.skip_depth == 0: self.skip_tag = None
        if tag == "title": self._t = False

    def handle_data(self, d):
        if self._t: self.title += d.strip()
        elif not self.skip_tag and d.strip(): self.out.append(d.strip())


def clean_html(html: str, limit: int = 8000) -> tuple:
    p = _Readable(); p.feed(html)
    safe, warnings = jobs.screen("\n".join(p.out))
    return p.title[:200], re.sub(r"\n{2,}", "\n", safe)[:limit], warnings


class Connector:
    name, purpose, data_shared, network_required, tools = "", "", "nothing", False, {}
    def call_tool(self, tool, args, ctx): raise NotImplementedError


class CompanyNotesConnector(Connector):
    """Local MCP-style connector: reads company notes the user saved on this machine. No network."""
    name, purpose, network_required = "local_company_notes", "Read company notes stored locally", False
    data_shared = "company name only (local lookup)"
    tools = {"read_company_notes": {"required": {"company": str}}}

    def call_tool(self, tool, args, ctx):
        f = ctx["data_dir"] / "company_notes" / (re.sub(r"[^a-z0-9]+", "_", args["company"].lower()).strip("_") + ".md")
        if not f.exists():
            return {"source": "local", "title": args["company"], "content": "", "trust_level": "user_provided"}
        return {"source": "local", "title": args["company"], "content": f.read_text()[:8000], "trust_level": "user_provided"}


class PublicWebConnector(Connector):
    """Fetches one public page, strips scripts/hidden content, screens injection text. http(s) only, SSRF-guarded."""
    name, purpose, network_required = "public_web", "Retrieve a public company/job web page", True
    data_shared = "the URL you provide (no resume data is ever sent)"
    tools = {"get_public_page": {"required": {"url": str}}}

    def __init__(self, allow_private=False): self.allow_private = allow_private

    def _guard(self, url):
        u = urlparse(url)
        if u.scheme not in ("http", "https") or not u.hostname:
            raise ToolError("Only http(s) URLs are allowed.")
        for info in socket.getaddrinfo(u.hostname, u.port or 443):
            ip = ipaddress.ip_address(info[4][0])
            if not self.allow_private and (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved):
                raise ToolError("Private or local addresses are not allowed.")

    def call_tool(self, tool, args, ctx):
        self._guard(args["url"])
        req = urllib.request.Request(args["url"], headers={"User-Agent": "CoverLetterAI/1.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            if "html" not in r.headers.get("Content-Type", "") and "text" not in r.headers.get("Content-Type", ""):
                raise ToolError("Only text/HTML pages are supported.")
            raw = r.read(1_000_000).decode("utf-8", "replace")
        title, content, warns = clean_html(raw)
        return {"source": "mcp", "title": title, "url": args["url"], "content": content, "retrieved_at": now(),
                "trust_level": "external_public", "source_label": "MCP RETRIEVED", "warnings": warns}


class McpRouter:
    def __init__(self, db, data_dir, allow_network, connectors=None):
        self.db, self.data_dir, self.allow_network = db, data_dir, allow_network
        self.reg = {c.name: c for c in (connectors or [CompanyNotesConnector(), PublicWebConnector()])}  # allowlist

    def _perm(self, c):
        r = self.db.one("SELECT permission FROM mcp_permissions WHERE connector=?", (c.name,))
        return r["permission"] if r else ("ASK" if c.network_required else "ALLOW")

    def list_servers(self):
        out = []
        for c in self.reg.values():
            r = self.db.one("SELECT last_used FROM mcp_permissions WHERE connector=?", (c.name,)) or {}
            out.append({"name": c.name, "purpose": c.purpose, "data_shared": c.data_shared,
                        "network_required": c.network_required, "permission": self._perm(c),
                        "last_used": r.get("last_used"), "tools": list(c.tools)})
        return out

    def set_permission(self, name, perm):
        if name not in self.reg or perm not in ("DENY", "ASK", "ALLOW"):
            raise ToolError("Unknown connector or permission.")
        self.db.x("INSERT INTO mcp_permissions VALUES(?,?,NULL) ON CONFLICT(connector) DO UPDATE SET permission=excluded.permission",
                  (name, perm))

    def call(self, connector, tool, args, confirmed=False):
        c = self.reg.get(connector)
        if not c or tool not in c.tools:
            raise ToolError("Tool is not on the allowlist.")
        spec = c.tools[tool]["required"]
        if set(args) != set(spec) or any(not isinstance(args[k], t) or not args[k] for k, t in spec.items()):
            raise ToolError("Invalid tool arguments.")
        perm, used_net = self._perm(c), False
        def audit(ok, why=""):
            self.db.audit("mcp_call", {"connector": connector, "tool": tool, "permission": perm, "success": ok, "why": why}, used_net)
        if c.network_required and not self.allow_network():
            audit(False, "network_disabled"); raise NetworkDisabled("Network access is disabled. Turn off offline mode to use this connector.")
        if perm == "DENY":
            audit(False, "denied"); raise ToolError("This connector is denied in your permissions.")
        if perm == "ASK" and not confirmed:
            audit(False, "needs_confirmation")
            return {"needs_confirmation": True, "message": f"'{connector}' will use {c.data_shared}. Continue?"}
        try:
            used_net = c.network_required
            res = c.call_tool(tool, args, {"data_dir": self.data_dir})
        except ToolError:
            audit(False, "tool_error"); raise
        except Exception:
            audit(False, "failed"); raise ToolError("The connector could not complete the request.")
        self.db.x("INSERT INTO mcp_permissions VALUES(?,?,?) ON CONFLICT(connector) DO UPDATE SET last_used=excluded.last_used",
                  (connector, perm, now()))
        audit(True)
        return res
