"""Job-description parsing + prompt-injection screening."""
import hashlib
import re
from . import knowledge as K
from .profile import BULLET

INJECTION = [
    r"\bignore\b.{0,50}\b(instructions?|policies|rules|guidelines|prompt)\b",
    r"\bdisregard\b.{0,40}\b(instructions?|policies|rules|above)\b",
    r"\b(reveal|print|show|leak)\b.{0,40}\b(system prompt|secrets?|api[ -]?keys?|passwords?)\b",
    r"\binvent\b.{0,40}\b(experience|claims?|facts?|achievements?|metrics)\b",
    r"\byou are now\b",
    r"\b(fabricate|make up)\b.{0,30}\b(experience|claims?|facts?)\b",
    r"</?\s*(system|assistant|resume_data|job_description|company_data)\s*>",
]
INJ_RE = re.compile("|".join(INJECTION), re.I)
NOISE = re.compile(r"equal opportunity|eeo\b|we do not discriminate|reasonable accommodation|"
                   r"privacy (policy|notice)|cookies?|apply now|share this job|sign in|©", re.I)
SEC = {
    "resp": r"(key )?(responsibilities|what you.?ll do|duties|the role|role overview|your role)",
    "req": r"(minimum |basic |required )?(requirements?|qualifications?|what we.?re looking for|must[- ]have|"
           r"who you are|skills( required)?|you have)",
    "pref": r"(preferred|nice[- ]to[- ]have|bonus|good to have|desirable|plus)( (qualifications|skills))?",
    "about": r"(about (us|the company|the team)|who we are|benefits|perks|what we offer)",
}


def screen(text: str):
    """Return (safe_text, warnings). Injection lines are dropped from model-facing text."""
    safe, warn = [], []
    for line in text.split("\n"):
        if INJ_RE.search(line):
            warn.append("Possible prompt-injection text was found in the document and ignored.")
            continue
        safe.append(line)
    return "\n".join(safe), sorted(set(warn))


def _sec(line):
    t = re.sub(r"[#*_:]+", "", line).strip().lower()
    if not t or len(t) > 45:
        return None
    for k, p in SEC.items():
        if re.fullmatch(p, t):
            return k
    return None


def analyze_job(text: str, title: str = "", company: str = "") -> dict:
    safe, warnings = screen(text)
    sections, cur = {"other": []}, "other"
    for line in safe.split("\n"):
        s = _sec(line)
        if s:
            cur = s
            sections.setdefault(cur, [])
        elif line.strip() and not NOISE.search(line):
            sections.setdefault(cur, []).append(line.strip())
    lines = [l for l in safe.split("\n") if l.strip()]
    m = re.search(r"(?im)^\s*(?:job title|position|role)\s*[:\-]\s*(.+)$", safe)
    title = title or (m.group(1).strip() if m else (lines[0].strip("# *") if lines else ""))
    m = re.search(r"(?im)^\s*company\s*[:\-]\s*(.+)$", safe)
    company = company or (m.group(1).strip() if m else "")
    m = re.search(r"(?im)^\s*location\s*[:\-]\s*(.+)$", safe)
    location = m.group(1).strip() if m else ""
    emp = next((t for t in ("full-time", "part-time", "internship", "contract", "remote", "hybrid")
                if t in safe.lower()), "")
    yrs = re.search(r"(\d+)\+?\s*(?:-\s*\d+\s*)?years?", safe, re.I)
    level = ("intern" if re.search(r"\bintern(ship)?\b", safe, re.I) else
             "junior" if re.search(r"\b(junior|entry[- ]level|fresher|graduate)\b", safe, re.I) else
             "senior" if re.search(r"\b(senior|lead|principal)\b", safe, re.I) else "")
    pref_text = "\n".join(sections.get("pref", []))
    pref = set(K.find_skills(pref_text))
    body = "\n".join(sections.get("resp", []) + sections.get("req", []) + sections.get("other", []))
    req = [c for c in K.find_skills(body) if c not in pref]
    req = sorted(req, key=lambda c: -K.find_skills(body)[c])
    resp = [BULLET.sub("", l) for l in sections.get("resp", [])][:8]
    qual = [BULLET.sub("", l) for l in sections.get("req", [])
            if re.search(r"degree|bachelor|master|certif|years?|diploma", l, re.I)][:6]
    return {
        "title": title, "company": company, "location": location, "employment_type": emp,
        "experience_level": level, "years_required": yrs.group(0) if yrs else "",
        "required_skills": req, "preferred_skills": sorted(pref),
        "responsibilities": resp, "qualifications": qual,
        "keywords": {"required": [K.display(c) for c in req], "preferred": [K.display(c) for c in pref]},
        "clean_text": safe, "warnings": warnings,
        "desc_hash": hashlib.sha256(re.sub(r"\s+", " ", safe.lower()).encode()).hexdigest(),
    }
