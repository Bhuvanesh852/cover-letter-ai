"""Optional cloud model providers (bring-your-own API key) + local secret store.

Design rules
- Cloud is OFF unless: network kill-switch is off AND the user approved that provider AND a key exists.
- Keys live in env vars, process memory, or (opt-in) a 0600 file. They are sent only in auth headers - never in URLs,
  prompts, logs, audit events or API responses (only a masked tail is ever shown).
- Only the evidence pack is sent (see service.ai_preview) - never the full resume, email, phone or links.
- Model names and free tiers change often, so models are listed live from each provider (list_models).
"""
import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import urlparse
from .llm import LocalModelProvider, ModelUnavailable
from .netguard import NetworkBlocked

# style: openai = OpenAI-compatible /chat/completions; gemini = Google generateContent; anthropic = /messages
PROVIDERS = {
    "gemini": {"label": "Google Gemini", "style": "gemini", "base": "https://generativelanguage.googleapis.com/v1beta",
               "env": ["GEMINI_API_KEY", "GOOGLE_API_KEY"], "model": "gemini-flash-latest", "key_url": "https://aistudio.google.com/apikey",
               "free": "Free tier available (Flash models, rate-limited). Google's free-tier terms may allow your inputs to be used to improve its models - avoid sending anything you would not want reviewed."},
    "openrouter": {"label": "OpenRouter", "style": "openai", "base": "https://openrouter.ai/api/v1", "env": ["OPENROUTER_API_KEY"], "model": "",
                   "key_url": "https://openrouter.ai/keys", "free_filter": True,
                   "free": "Models whose id ends in ':free' cost $0 (documented limits: ~20 requests/min and a daily cap). Free variants may have different data-use terms - check the model page."},
    "groq": {"label": "Groq", "style": "openai", "base": "https://api.groq.com/openai/v1", "env": ["GROQ_API_KEY"], "model": "",
             "key_url": "https://console.groq.com/keys", "free": "Has had a rate-limited free tier; check current limits and terms."},
    "openai": {"label": "OpenAI", "style": "openai", "base": "https://api.openai.com/v1", "env": ["OPENAI_API_KEY"], "model": "gpt-4o-mini",
               "key_url": "https://platform.openai.com/api-keys", "free": "Paid API (no standing free tier)."},
    "xai": {"label": "xAI Grok", "style": "openai", "base": "https://api.x.ai/v1", "env": ["XAI_API_KEY"], "model": "",
            "key_url": "https://console.x.ai", "free": "Paid or promotional credits - check your console."},
    "anthropic": {"label": "Anthropic Claude", "style": "anthropic", "base": "https://api.anthropic.com/v1", "env": ["ANTHROPIC_API_KEY"], "model": "",
                  "key_url": "https://console.anthropic.com/settings/keys", "free": "Paid API."},
    "mistral": {"label": "Mistral", "style": "openai", "base": "https://api.mistral.ai/v1", "env": ["MISTRAL_API_KEY"], "model": "mistral-small-latest",
                "key_url": "https://console.mistral.ai/api-keys", "free": "Check current free/experiment tier terms."},
    "deepseek": {"label": "DeepSeek", "style": "openai", "base": "https://api.deepseek.com/v1", "env": ["DEEPSEEK_API_KEY"], "model": "deepseek-chat",
                 "key_url": "https://platform.deepseek.com/api_keys", "free": "Paid API."},
    "custom": {"label": "Custom OpenAI-compatible server", "style": "openai", "base": "http://127.0.0.1:1234/v1", "env": ["CUSTOM_LLM_API_KEY"], "model": "",
               "key_optional": True, "free": "e.g. LM Studio, llama.cpp server, vLLM. Loopback addresses stay on your machine and need no approval."},
}
KEY_RE = re.compile(r"[A-Za-z0-9._\-:~+/=]{8,512}")   # blocks header injection / whitespace


def is_loopback(url: str) -> bool:
    return (urlparse(url).hostname or "") in ("localhost", "127.0.0.1", "::1")


class Secrets:
    """env var > session memory > optional 0600 file. A file is plain JSON protected only by OS permissions -
    prefer environment variables for long-term use."""
    def __init__(self, path: Path):
        self.path, self.mem = Path(path), {}

    def _file(self) -> dict:
        try: return json.loads(self.path.read_text())
        except Exception: return {}

    def get(self, pid: str, env_names=()):
        for n in env_names:
            if os.environ.get(n): return os.environ[n].strip(), "env"
        if pid in self.mem: return self.mem[pid], "session"
        f = self._file().get(pid)
        return (f, "file") if f else (None, None)

    def set(self, pid: str, key: str, persist: bool = False):
        key = (key or "").strip()
        if not KEY_RE.fullmatch(key): raise ValueError("That does not look like a valid API key.")
        self.mem[pid] = key
        if persist:
            data = self._file(); data[pid] = key
            fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as fh: json.dump(data, fh)
            os.chmod(self.path, 0o600)

    def delete(self, pid: str):
        self.mem.pop(pid, None)
        data = self._file()
        if pid in data:
            data.pop(pid); fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as fh: json.dump(data, fh)

    def info(self, pid: str, env_names=()) -> dict:
        k, src = self.get(pid, env_names)
        return {"has_key": bool(k), "key_source": src, "masked": ("••••" + k[-4:]) if k else None}


class CloudProvider(LocalModelProvider):
    kind = "cloud"

    def __init__(self, pid, spec, key, model, temperature=0.35, top_p=0.9, timeout=60, max_tokens=900):
        self.pid, self.spec, self._key, self.name = pid, spec, key, model
        self.base = spec["base"].rstrip("/")
        self.temperature, self.top_p, self.timeout, self.max_tokens = temperature, top_p, timeout, max_tokens
        if not (self.base.startswith("https://") or is_loopback(self.base)):
            raise ModelUnavailable("Cloud providers must use https.")

    # ---- transport ----
    def _headers(self):
        s, h = self.spec["style"], {"Content-Type": "application/json", "User-Agent": "CoverLetterAI/1.0"}
        if s == "gemini": h["x-goog-api-key"] = self._key or ""          # header, never the URL
        elif s == "anthropic": h.update({"x-api-key": self._key or "", "anthropic-version": "2023-06-01"})
        elif self._key: h["Authorization"] = "Bearer " + self._key
        if self.pid == "openrouter": h["X-Title"] = "CoverLetter AI"
        return h

    def _request(self, method, path, body=None):
        data = json.dumps(body).encode() if body is not None else None
        for attempt in (0, 1):
            req = urllib.request.Request(self.base + path, data, self._headers(), method=method)
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    return json.loads(r.read())
            except urllib.error.HTTPError as e:
                if e.code in (429, 500, 502, 503) and attempt == 0:
                    time.sleep(min(float(e.headers.get("Retry-After") or 1), 5) if str(e.headers.get("Retry-After") or "1").replace(".", "").isdigit() else 1)
                    continue
                raise ModelUnavailable(self._explain(e.code)) from None
            except (NetworkBlocked, urllib.error.URLError, TimeoutError, OSError) as e:
                blocked = isinstance(e, NetworkBlocked) or isinstance(getattr(e, "reason", None), NetworkBlocked)
                raise ModelUnavailable("Network is off (offline mode)." if blocked else f"Could not reach {self.spec['label']}.") from None
            except ValueError:
                raise ModelUnavailable(f"{self.spec['label']} returned an unreadable response.") from None

    def _explain(self, code: int) -> str:
        who = self.spec["label"]
        return {400: f"{who} rejected the request (check the model name).", 401: f"{who} rejected the API key.",
                402: f"{who} says credits/payment are required.", 403: f"{who} denied access (key permissions or region).",
                404: f"{who} could not find that model - use 'List models'.",
                429: f"{who} rate limit reached (free tiers are limited). Wait and retry, or use the local engine."}.get(
                    code, f"{who} is unavailable right now (HTTP {code}).")

    # ---- API ----
    def generate(self, system, prompt, **opts):
        if not self.name: raise ModelUnavailable("No model selected - open AI settings and choose one with 'List models'.")
        mt = int(opts.get("max_tokens", self.max_tokens)); s = self.spec["style"]
        if s == "gemini":
            m = self.name.replace("models/", "")
            out = self._request("POST", f"/models/{m}:generateContent", {
                "systemInstruction": {"parts": [{"text": system}]}, "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                "generationConfig": {"temperature": self.temperature, "topP": self.top_p, "maxOutputTokens": mt}})
            try: return "".join(p.get("text", "") for p in out["candidates"][0]["content"]["parts"]).strip()
            except (KeyError, IndexError, TypeError): raise ModelUnavailable("Gemini returned no text (the content may have been filtered).") from None
        if s == "anthropic":
            out = self._request("POST", "/messages", {"model": self.name, "max_tokens": mt, "system": system, "temperature": self.temperature,
                                                      "messages": [{"role": "user", "content": prompt}]})
            try: return "".join(b.get("text", "") for b in out["content"]).strip()
            except (KeyError, TypeError): raise ModelUnavailable("Anthropic returned no text.") from None
        out = self._request("POST", "/chat/completions", {"model": self.name, "temperature": self.temperature, "top_p": self.top_p, "max_tokens": mt,
                                                          "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}]})
        try: return (out["choices"][0]["message"]["content"] or "").strip()
        except (KeyError, IndexError, TypeError): raise ModelUnavailable(f"{self.spec['label']} returned no text.") from None

    def list_models(self, free_only=False) -> list:
        out, s, res = self._request("GET", "/models"), self.spec["style"], []
        if s == "gemini":
            for m in out.get("models", []):
                if "generateContent" in m.get("supportedGenerationMethods", []): res.append({"id": m["name"].replace("models/", ""), "free": None})
        else:
            for m in out.get("data", []):
                pr = m.get("pricing") or {}
                free = (str(pr.get("prompt")) in ("0", "0.0") and str(pr.get("completion")) in ("0", "0.0")) if pr else None
                res.append({"id": m["id"], "free": free})
        if free_only: res = [m for m in res if m["free"] or m["id"].endswith(":free")]
        return sorted(res, key=lambda m: m["id"])

    def health_check(self) -> dict:
        try:
            n = len(self.list_models())
            return {"ok": True, "provider": self.pid, "model": self.name, "models_available": n}
        except ModelUnavailable as e:
            return {"ok": False, "provider": self.pid, "model": self.name, "error": str(e)}
