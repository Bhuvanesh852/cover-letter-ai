"""Local RAG: hashing embedder + BM25 + metadata filters, hybrid-fused, incremental index."""
import hashlib
import json
import math
from collections import Counter
from . import knowledge as K
from .db import DB, uid, now


class HashingEmbedder:
    """Dependency-free local embedder (feature hashing of skill-canonicalised uni/bi-grams).
    Swap for any object with the same embed() signature (e.g. a local sentence-transformer)."""
    name, dim = "hashing-v1", 1024

    def _toks(self, text):
        return [w for w in K.words(K.canon_text(text)) if w not in K.STOP and len(w) > 1]

    def embed(self, text: str) -> dict:
        t = [K.stem(w) for w in self._toks(text)]
        feats = Counter(t) + Counter(a + "_" + b for a, b in zip(t, t[1:]))
        vec = {}
        for f, c in feats.items():
            h = int(hashlib.md5(f.encode()).hexdigest()[:8], 16)
            vec[h % self.dim] = vec.get(h % self.dim, 0) + (1 + math.log(c)) * (1 if h & 1 else -1)
        n = math.sqrt(sum(v * v for v in vec.values())) or 1
        return {k: v / n for k, v in vec.items()}


def cosine(a: dict, b: dict) -> float:
    if len(a) > len(b):
        a, b = b, a
    return sum(v * b.get(k, 0) for k, v in a.items())


def _index_text(c: dict) -> str:
    return f"{c['section']} {c['subsection']} {c['text']}"


class RagStore:
    def __init__(self, db: DB, embedder=None):
        self.db, self.emb = db, embedder or HashingEmbedder()
        self._cache = {}   # candidate_id -> prepared index (chunks, tokenised docs, df, avg length)

    def invalidate(self, cid=None):
        self._cache.pop(cid, None) if cid else self._cache.clear()

    def _prepared(self, cid):
        p = self._cache.get(cid)
        if p is None:
            rows = self.db.q("SELECT * FROM chunks WHERE candidate_id=? AND use_state!='do_not_use'", (cid,))
            for r in rows: r["vec"] = json.loads(r["vec"])
            docs = [[K.stem(w) for w in self.emb._toks(_index_text(c))] for c in rows]
            p = self._cache[cid] = {"chunks": rows, "docs": docs, "df": Counter(t for d in docs for t in set(d)),
                                    "avg": (sum(map(len, docs)) / len(docs)) if docs else 1}
        return p

    def versions(self):
        return {"embedding": self.emb.name, "chunking": "chunk-v1", "retrieval": "hybrid-bm25-cos-v1"}

    def sync_candidate(self, candidate_id: str, items: list, doc_id: str = None) -> dict:
        """Incrementally (re)index document-derived chunks; only changed chunks are re-embedded."""
        existing = {r["sha"]: r for r in self.db.q(
            "SELECT id, sha FROM chunks WHERE candidate_id=? AND origin='document'", (candidate_id,))}
        keep, added = set(), 0
        for it in items:
            sha = hashlib.sha256(f"{it['section']}|{it['subsection']}|{it['text']}".encode()).hexdigest()
            keep.add(sha)
            if sha in existing:
                continue
            self.db.x("INSERT INTO chunks VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                uid("chunk"), candidate_id, doc_id, "document", it["section"], it["subsection"], it["text"], sha,
                it.get("source_type", "resume"), it.get("fact_status", "verified"), "use",
                json.dumps(self.emb.embed(_index_text(it))), json.dumps(self.versions()), now()))
            added += 1
        removed = 0
        self.invalidate(candidate_id)
        for sha, r in existing.items():
            if sha not in keep:
                self.db.x("DELETE FROM chunks WHERE id=?", (r["id"],))
                removed += 1
        return {"added": added, "removed": removed, "unchanged": len(keep) - added}

    def add_user_evidence(self, candidate_id: str, section: str, subsection: str, text: str) -> str:
        self.invalidate(candidate_id)
        cid = uid("chunk")
        it = {"section": section, "subsection": subsection, "text": text}
        self.db.x("INSERT INTO chunks VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
            cid, candidate_id, None, "user", section, subsection, text,
            hashlib.sha256(text.encode()).hexdigest(), "user_added", "user_added", "use",
            json.dumps(self.emb.embed(_index_text(it))), json.dumps(self.versions()), now()))
        return cid

    def active_chunks(self, candidate_id: str) -> list:
        """Strict per-candidate isolation + user overrides ('do_not_use' is never retrieved). Treat results as read-only."""
        return self._prepared(candidate_id)["chunks"]

    def search(self, candidate_id: str, query: str, k: int = 8, sections=None) -> list:
        p = self._prepared(candidate_id)
        idx = [i for i, c in enumerate(p["chunks"]) if not sections or c["section"] in sections]
        if not idx:
            return []
        n, df, avg = len(p["chunks"]), p["df"], p["avg"]
        q_stems = set(K.stem(w) for w in self.emb._toks(query))
        bm = []
        for i in idx:
            d = p["docs"][i]; tf = Counter(d); s = 0.0
            for t in q_stems:
                if t in tf:
                    idf = math.log(1 + (n - df[t] + .5) / (df[t] + .5))
                    s += idf * tf[t] * 2.5 / (tf[t] + 1.5 * (.25 + .75 * len(d) / avg))
            bm.append(s)
        qv = self.emb.embed(query)
        sem = [cosine(qv, p["chunks"][i]["vec"]) for i in idx]
        mb, ms = max(bm), max(sem)
        out = []
        for i, b, sv in zip(idx, bm, sem):
            c = p["chunks"][i]
            score = (0.6 * (b / mb if mb else 0) + 0.4 * (max(sv, 0) / ms if ms > 0 else 0)) if (b or sv > 0) else 0
            out.append({"chunk_id": c["id"], "section": c["section"], "subsection": c["subsection"], "text": c["text"],
                        "source_type": c["source_type"], "fact_status": c["fact_status"],
                        "score": round(score, 4), "bm25": round(b, 3), "semantic": round(sv, 3)})
        out.sort(key=lambda r: -r["score"])
        return [o for o in out[:k] if o["score"] > 0]
