"""Export engine. Every format is written with the standard library (no pip packages needed).
If reportlab is installed it is used for nicer PDFs; otherwise a built-in PDF writer is used.
Formats: txt, md, html, rtf, docx, odt, pdf, json, plus a zip bundle of all of them."""
import io
import json
import re
import unicodedata
import zipfile
from html import escape as h_esc
from xml.sax.saxutils import escape as x_esc

FORMATS = ("pdf", "docx", "odt", "rtf", "html", "txt", "md", "json")
MIMES = {
    "pdf": "application/pdf",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "odt": "application/vnd.oasis.opendocument.text", "rtf": "application/rtf",
    "html": "text/html; charset=utf-8", "txt": "text/plain; charset=utf-8",
    "md": "text/markdown; charset=utf-8", "json": "application/json", "zip": "application/zip",
}
FONTS = {"ats-minimal": ("Arial", "Helvetica", "Helvetica-Bold"), "classic": ("Times New Roman", "Times-Roman", "Times-Bold")}


def blocks(content: dict) -> list:
    """Letter as [(text, bold, space_after_pt)] - the single source every format renders from."""
    h = content["header"]
    b = [(h["name"], True, 0), (h["contact"], False, 0), (h["date"], False, 12),
         ("Hiring Team", False, 0), (h["company"], False, 12),
         (f"Re: Application for {h['role']}", True, 12), (h["greeting"], False, 8)]
    b += [(p, False, 8) for p in content["paragraphs"]]
    b += [(h["signature"], False, 0), (h["name"], False, 0)]
    return [x for x in b if x[0]]


def compose_text(content: dict, md: bool = False) -> str:
    h = content["header"]
    lines = [h["name"], h["contact"], h["date"], "", "Hiring Team", h["company"], "",
             f"Re: Application for {h['role']}", "", h["greeting"], ""]
    for p in content["paragraphs"]:
        lines += [p, ""]
    lines += [h["signature"], h["name"]]
    txt = "\n".join(l for i, l in enumerate(lines) if l != "" or (i and lines[i - 1] != ""))
    return txt.replace(f"Re: Application for {h['role']}", f"**Re: Application for {h['role']}**") if md else txt


def safe_filename(content: dict, ext: str) -> str:
    h = content["header"]
    raw = f"{h['name']}_Cover_Letter_{h['role']}_{h['company']}"
    raw = unicodedata.normalize("NFKD", raw).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Za-z0-9]+", "_", raw).strip("_")[:90] + "." + ext


def to_html(content: dict, template="ats-minimal") -> bytes:
    font = "Georgia, 'Times New Roman', serif" if template == "classic" else "Arial, Helvetica, sans-serif"
    def para(t, bold, sp):
        style = ' style="margin-bottom:0"' if not sp else ""
        inner = f"<strong>{h_esc(t)}</strong>" if bold else h_esc(t)
        return f"<p{style}>{inner}</p>"
    body = "".join(para(*b) for b in blocks(content))
    doc = (f"<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><title>Cover letter - {h_esc(content['header']['role'])}</title>"
           f"<style>body{{font:11pt/1.5 {font};max-width:42em;margin:2em auto;padding:0 1em;color:#111}}p{{margin:0 0 .8em}}"
           f"@media print{{body{{margin:0}}}}</style></head><body>{body}</body></html>")
    return doc.encode()


def _rtf_escape(s: str) -> str:
    out = []
    for ch in s:
        if ch in "\\{}": out.append("\\" + ch)
        elif ord(ch) < 128: out.append(ch)
        else:
            n = ord(ch); n = n - 65536 if n > 32767 else n
            out.append(f"\\u{n}?")
    return "".join(out)


def to_rtf(content: dict, template="ats-minimal") -> bytes:
    font = FONTS[template][0]
    def para(t, bold, sp):
        txt = _rtf_escape(t)
        return "\\pard\\sa%d{%s}\\par\n" % (sp * 20, ("\\b " + txt + "\\b0") if bold else txt)
    paras = "".join(para(*b) for b in blocks(content))
    return (f"{{\\rtf1\\ansi\\deff0{{\\fonttbl{{\\f0 {font};}}}}\\f0\\fs22\n{paras}}}").encode("ascii")


def to_docx(content: dict, template="ats-minimal") -> bytes:
    font = FONTS[template][0]
    def para(t, bold, sp):
        rpr = f"<w:rPr><w:rFonts w:ascii=\"{font}\" w:hAnsi=\"{font}\"/>{'<w:b/>' if bold else ''}<w:sz w:val=\"22\"/></w:rPr>"
        return (f"<w:p><w:pPr><w:spacing w:after=\"{sp * 20}\"/></w:pPr><w:r>{rpr}"
                f"<w:t xml:space=\"preserve\">{x_esc(t)}</w:t></w:r></w:p>")
    doc = ("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>"
           + "".join(para(*b) for b in blocks(content))
           + "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1296\" w:right=\"1440\" w:bottom=\"1296\" w:left=\"1440\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                   "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                   "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>")
        z.writestr("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                   "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>")
        z.writestr("word/document.xml", doc)
    return buf.getvalue()


def to_odt(content: dict, template="ats-minimal") -> bytes:
    font = FONTS[template][0]
    paras = "".join(f"<text:p text:style-name=\"{'B' if bold else 'P'}\">{x_esc(t)}</text:p>" for t, bold, _ in blocks(content))
    doc = ("<?xml version=\"1.0\" encoding=\"UTF-8\"?><office:document-content xmlns:office=\"urn:oasis:names:tc:opendocument:xmlns:office:1.0\" "
           "xmlns:text=\"urn:oasis:names:tc:opendocument:xmlns:text:1.0\" xmlns:style=\"urn:oasis:names:tc:opendocument:xmlns:style:1.0\" "
           "xmlns:fo=\"urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0\" office:version=\"1.2\">"
           f"<office:automatic-styles><style:style style:name=\"P\" style:family=\"paragraph\"><style:paragraph-properties fo:margin-bottom=\"0.15in\"/>"
           f"<style:text-properties style:font-name=\"{font}\" fo:font-size=\"11pt\"/></style:style>"
           f"<style:style style:name=\"B\" style:family=\"paragraph\"><style:paragraph-properties fo:margin-bottom=\"0.15in\"/>"
           f"<style:text-properties style:font-name=\"{font}\" fo:font-size=\"11pt\" fo:font-weight=\"bold\"/></style:style></office:automatic-styles>"
           f"<office:body><office:text>{paras}</office:text></office:body></office:document-content>")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype"), "application/vnd.oasis.opendocument.text")  # must be first, stored
        z.writestr("META-INF/manifest.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><manifest:manifest xmlns:manifest=\"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0\" manifest:version=\"1.2\">"
                   "<manifest:file-entry manifest:full-path=\"/\" manifest:media-type=\"application/vnd.oasis.opendocument.text\"/>"
                   "<manifest:file-entry manifest:full-path=\"content.xml\" manifest:media-type=\"text/xml\"/></manifest:manifest>", compress_type=zipfile.ZIP_DEFLATED)
        z.writestr("content.xml", doc, compress_type=zipfile.ZIP_DEFLATED)
    return buf.getvalue()


def _wrap(text: str, width: int) -> list:
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + (1 if cur else 0) > width:
            lines.append(cur); cur = w
        else:
            cur = f"{cur} {w}".strip()
    return lines + ([cur] if cur else [])


def _pdf_fallback(content: dict, template: str) -> bytes:
    """Minimal dependency-free PDF (A4, Helvetica/Times, latin-1 text, selectable)."""
    _, font, bold = FONTS[template]
    pages, cur, y = [], [], 800
    def esc(s): return s.encode("latin-1", "replace").decode("latin-1").replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    for text, is_bold, sp in blocks(content):
        for line in _wrap(text, 84):
            if y < 60:
                pages.append(cur); cur, y = [], 800
            cur.append(f"BT /{'F2' if is_bold else 'F1'} 11 Tf 72 {y} Td ({esc(line)}) Tj ET"); y -= 15
        y -= sp
    pages.append(cur)
    objs = ["<< /Type /Catalog /Pages 2 0 R >>", None,
            f"<< /Type /Font /Subtype /Type1 /BaseFont /{font} /Encoding /WinAnsiEncoding >>",
            f"<< /Type /Font /Subtype /Type1 /BaseFont /{bold} /Encoding /WinAnsiEncoding >>"]
    kids = []
    for p in pages:
        stream = "\n".join(p)
        objs.append(f"<< /Length {len(stream.encode('latin-1', 'replace'))} >>\nstream\n{stream}\nendstream")
        cid = len(objs)
        objs.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents {cid} 0 R /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> >>")
        kids.append(f"{len(objs)} 0 R")
    objs[1] = f"<< /Type /Pages /Kids [{' '.join(kids)}] /Count {len(kids)} >>"
    out, offs = bytearray(b"%PDF-1.4\n"), []
    for i, o in enumerate(objs, 1):
        offs.append(len(out)); out += f"{i} 0 obj\n{o}\nendobj\n".encode("latin-1", "replace")
    x = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
    for o in offs: out += f"{o:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{x}\n%%EOF".encode()
    return bytes(out)


def to_pdf(content: dict, template="ats-minimal") -> bytes:
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.platypus import SimpleDocTemplate, Paragraph
    except ImportError:
        return _pdf_fallback(content, template)
    _, font, bold = FONTS[template]
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=inch, rightMargin=inch, topMargin=.9 * inch, bottomMargin=.9 * inch,
                            title=f"Cover letter - {content['header']['role']}", author=content["header"]["name"])
    doc.build([Paragraph(x_esc(t), ParagraphStyle("p", fontName=bold if b else font, fontSize=11, leading=15, spaceAfter=sp))
               for t, b, sp in blocks(content)])
    return buf.getvalue()


def to_json(content: dict, template="ats-minimal") -> bytes:
    return json.dumps({"header": content["header"], "paragraphs": content["paragraphs"], "text": compose_text(content)},
                      indent=2, ensure_ascii=False).encode()


_RENDER = {"pdf": to_pdf, "docx": to_docx, "odt": to_odt, "rtf": to_rtf, "html": to_html, "json": to_json,
           "txt": lambda c, t: compose_text(c).encode(), "md": lambda c, t: compose_text(c, md=True).encode()}


def export(content: dict, fmt: str, template: str = "ats-minimal") -> tuple:
    """Returns (bytes, mime, filename)."""
    fmt = fmt.lower()
    if template not in FONTS: template = "ats-minimal"
    if fmt == "zip":
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for f in FORMATS: z.writestr(safe_filename(content, f), _RENDER[f](content, template))
        return buf.getvalue(), MIMES["zip"], safe_filename(content, "zip")
    if fmt not in _RENDER: raise ValueError("Unsupported export format")
    return _RENDER[fmt](content, template), MIMES[fmt], safe_filename(content, fmt)


def export_many(contents: list, template="ats-minimal", fmts=("pdf", "docx", "txt")) -> bytes:
    """One zip with each letter in the chosen formats (used by batch mode)."""
    buf, used = io.BytesIO(), set()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for c in contents:
            for f in fmts:
                name, n = safe_filename(c, f), 1
                while name in used: n += 1; name = safe_filename(c, f).replace(f".{f}", f"_{n}.{f}")
                used.add(name); z.writestr(name, _RENDER[f](c, template))
    return buf.getvalue()
