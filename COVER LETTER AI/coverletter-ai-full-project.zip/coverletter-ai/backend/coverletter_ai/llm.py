"""Pluggable local model layer. The app never calls a cloud model; Ollama is reached on loopback only."""
import json
import urllib.request


class ModelUnavailable(Exception):
    pass


class LocalModelProvider:
    kind, name = "base", "base"
    def health_check(self) -> dict: raise NotImplementedError
    def generate(self, system: str, prompt: str, **opts) -> str: raise NotImplementedError


class OllamaProvider(LocalModelProvider):
    """Adapter for a local Ollama (llama.cpp-based) runtime. Loopback only by default."""
    kind = "slm"

    def __init__(self, url: str, model: str, temperature=0.35, top_p=0.9, num_ctx=8192):
        self.url, self.name = url.rstrip("/"), model
        self.opts = {"temperature": temperature, "top_p": top_p, "num_ctx": num_ctx}

    def _post(self, path, body, timeout=300):
        req = urllib.request.Request(self.url + path, json.dumps(body).encode(), {"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.loads(r.read())
        except Exception as e:
            raise ModelUnavailable(f"Local model runtime not reachable at {self.url}") from e

    def health_check(self) -> dict:
        try:
            with urllib.request.urlopen(self.url + "/api/tags", timeout=2) as r:
                tags = [m["name"] for m in json.loads(r.read()).get("models", [])]
            return {"ok": self.name in tags or any(t.startswith(self.name) for t in tags),
                    "provider": "ollama", "model": self.name, "installed": tags}
        except Exception:
            return {"ok": False, "provider": "ollama", "model": self.name, "installed": []}

    def generate(self, system, prompt, **opts):
        o = {**self.opts, **{k: v for k, v in opts.items() if k != "max_tokens"}}
        if "max_tokens" in opts: o["num_predict"] = opts["max_tokens"]
        body = {"model": self.name, "system": system, "prompt": prompt, "stream": False, "options": o}
        return self._post("/api/generate", body).get("response", "").strip()


class TemplateProvider(LocalModelProvider):
    """Deterministic evidence-composer used when no SLM is installed. It is NOT a language model:
    it assembles sentences directly from retrieved evidence (see generator.compose_template)."""
    kind, name = "template", "template-engine (no SLM detected)"
    def health_check(self): return {"ok": True, "provider": "template", "model": self.name, "installed": []}


def pick_provider(settings) -> LocalModelProvider:
    if settings.provider in ("auto", "ollama"):
        p = OllamaProvider(settings.ollama_url, settings.ollama_model, settings.temperature, settings.top_p)
        if settings.provider == "ollama" or p.health_check()["ok"]:
            return p
    return TemplateProvider()
