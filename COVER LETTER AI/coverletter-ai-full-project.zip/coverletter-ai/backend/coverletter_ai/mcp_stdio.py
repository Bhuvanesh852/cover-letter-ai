"""Claude Desktop / local MCP transport: newline-delimited JSON-RPC over stdin/stdout.
stdout carries ONLY protocol messages; diagnostics go to stderr."""
import json
import sys
from .mcp_server import McpServer
from .service import App


def main():
    app = App()
    srv = McpServer(app)
    print(f"[coverletter-ai] MCP stdio ready | offline={app.s.offline} | data={app.s.data_dir}", file=sys.stderr, flush=True)
    for line in sys.stdin:
        line = line.strip()
        if not line: continue
        try:
            resp = srv.handle(json.loads(line))
        except ValueError:
            resp = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}
        if resp is not None:
            sys.stdout.write(json.dumps(resp, ensure_ascii=False) + "\n"); sys.stdout.flush()


if __name__ == "__main__":
    main()
