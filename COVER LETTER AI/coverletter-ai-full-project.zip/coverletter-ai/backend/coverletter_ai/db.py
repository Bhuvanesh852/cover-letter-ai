import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path

SCHEMA = """
PRAGMA journal_mode=WAL; PRAGMA secure_delete=ON; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS candidates(
  id TEXT PRIMARY KEY, name TEXT NOT NULL, profile_json TEXT NOT NULL, is_demo INTEGER DEFAULT 0,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS documents(
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  filename TEXT, kind TEXT, sha256 TEXT, size INTEGER, pages INTEGER, quality TEXT, text TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS chunks(
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  doc_id TEXT, origin TEXT NOT NULL, section TEXT, subsection TEXT, text TEXT NOT NULL, sha TEXT NOT NULL,
  source_type TEXT, fact_status TEXT, use_state TEXT DEFAULT 'use', vec TEXT, versions TEXT, created_at TEXT);
CREATE INDEX IF NOT EXISTS idx_chunks_cand ON chunks(candidate_id);
CREATE TABLE IF NOT EXISTS jobs(
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  title TEXT, company TEXT, desc_hash TEXT, job_json TEXT NOT NULL, created_at TEXT);
CREATE TABLE IF NOT EXISTS letters(
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  job_id TEXT NOT NULL, version INTEGER NOT NULL, parent_id TEXT, content_json TEXT NOT NULL,
  validation_json TEXT, meta_json TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS applications(
  id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  job_id TEXT, letter_id TEXT, company TEXT, role TEXT, url TEXT, location TEXT, status TEXT,
  applied_date TEXT, followup_date TEXT, notes TEXT, created_at TEXT, updated_at TEXT);
CREATE TABLE IF NOT EXISTS mcp_permissions(connector TEXT PRIMARY KEY, permission TEXT NOT NULL, last_used TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS audit_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, event TEXT, detail TEXT, network_used INTEGER DEFAULT 0);
"""
MIGRATIONS = [SCHEMA, "CREATE INDEX IF NOT EXISTS idx_letters_job ON letters(job_id); CREATE INDEX IF NOT EXISTS idx_jobs_cand ON jobs(candidate_id); CREATE INDEX IF NOT EXISTS idx_apps_cand ON applications(candidate_id);"]  # append future migrations; schema_version is tracked in meta


def now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def uid(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


class DB:
    def __init__(self, path):
        if str(path) != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self._migrate()

    def _migrate(self):
        with self.lock:
            self.conn.executescript("CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);")
            row = self.conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
            cur = int(row["value"]) if row else 0
            for i, sql in enumerate(MIGRATIONS[cur:], start=cur + 1):
                self.conn.executescript(sql)
                self.conn.execute("INSERT OR REPLACE INTO meta VALUES('schema_version',?)", (str(i),))
            self.conn.commit()

    def q(self, sql, args=()):
        with self.lock:
            return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    def one(self, sql, args=()):
        r = self.q(sql, args)
        return r[0] if r else None

    def x(self, sql, args=()):
        with self.lock:
            self.conn.execute(sql, args)
            self.conn.commit()

    def audit(self, event, detail=None, network=False):
        # Only IDs / statuses are logged - never resume or letter text.
        self.x("INSERT INTO audit_events(ts,event,detail,network_used) VALUES(?,?,?,?)",
               (now(), event, json.dumps(detail or {}), int(network)))
