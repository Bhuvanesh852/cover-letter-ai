"""Resume text -> normalized candidate profile -> RAG items."""
import re
from . import knowledge as K

HEADINGS = {
    "summary": r"(professional )?(summary|profile|objective|about( me)?)",
    "education": r"education( and training)?|academic( background| qualifications)?",
    "skills": r"(technical |key |core )?skills|technologies|tech stack|competencies",
    "projects": r"(academic |personal |key )?projects?",
    "experience": r"(work |professional |relevant )?experience|employment( history)?|internships?",
    "certifications": r"certifications?|licenses?|courses|training",
    "achievements": r"achievements?|awards?|accomplishments|honou?rs",
}
BULLET = re.compile(r"^\s*([-*•▪●‣]|\d+[.)])\s+")
EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
PHONE = re.compile(r"(?<!\d)(\+?\d[\d\s().-]{8,15}\d)(?!\d)")


def _heading(line: str):
    t = re.sub(r"[#*_:]+", "", line).strip().lower()
    if not t or len(t) > 40:
        return None
    for key, pat in HEADINGS.items():
        if re.fullmatch(pat, t):
            return key
    return None


def split_sections(text: str) -> dict:
    sec, cur = {"header": []}, "header"
    for line in text.split("\n"):
        h = _heading(line)
        if h:
            cur = h
            sec.setdefault(cur, [])
        else:
            sec.setdefault(cur, []).append(line)
    return sec


def _items(lines: list) -> list:
    """Group lines into [{name, bullets}] items (projects / experience)."""
    items, cur = [], None
    for raw in lines:
        line = raw.strip()
        if not line:
            cur = None if cur and cur["bullets"] else cur
            continue
        if BULLET.match(line):
            if cur is None:
                cur = {"name": "", "bullets": []}
                items.append(cur)
            cur["bullets"].append(BULLET.sub("", line).strip())
        else:
            m = re.match(r"^(.{3,60}?)\s*[:\u2013\u2014-]\s+(.{15,})$", line)
            if m and len(m.group(1).split()) <= 8:
                items.append({"name": m.group(1).strip(), "bullets": [m.group(2).strip()]})
                cur = None
            else:
                cur = {"name": line, "bullets": []}
                items.append(cur)
    return [i for i in items if i["name"] or i["bullets"]]


def _list_items(lines: list) -> list:
    out = []
    for raw in lines:
        line = BULLET.sub("", raw.strip())
        if line:
            out.append(line)
    return out


def extract_profile(text: str, name: str = "") -> dict:
    sec = split_sections(text)
    header = [l.strip() for l in sec.get("header", []) if l.strip()]
    if not name and header:
        first = re.sub(r"[#*_]", "", header[0]).strip()
        if len(first.split()) <= 5 and not re.search(r"[\d@]", first):
            name = first
    head_text = "\n".join(header)
    email = (EMAIL.search(text) or [""])[0] if EMAIL.search(text) else ""
    pm = PHONE.search(head_text)
    links = {
        "github": re.findall(r"(?:https?://)?(?:www\.)?github\.com/[\w./-]+", text),
        "linkedin": re.findall(r"(?:https?://)?(?:[a-z]{2,3}\.)?linkedin\.com/[\w./-]+", text),
    }
    skills = []
    for line in sec.get("skills", []):
        line = BULLET.sub("", line.strip())
        if ":" in line and len(line.split(":")[0]) < 30:
            line = line.split(":", 1)[1]
        skills += [s.strip() for s in re.split(r"[,;|•·]", line) if s.strip()]
    return {
        "name": name,
        "email": email,
        "phone": pm.group(1).strip() if pm else "",
        "location": "",
        "summary": " ".join(l.strip() for l in sec.get("summary", []) if l.strip()),
        "education": _list_items(sec.get("education", [])),
        "skills": skills,
        "experience": _items(sec.get("experience", [])),
        "projects": _items(sec.get("projects", [])),
        "certifications": _list_items(sec.get("certifications", [])),
        "achievements": _list_items(sec.get("achievements", [])),
        "links": links,
    }


def profile_to_items(p: dict) -> list:
    """Semantic chunking: one chunk per resume item, each with metadata."""
    out = []

    def add(section, sub, text, ftype="verified"):
        if text and text.strip():
            out.append({"section": section, "subsection": sub, "text": text.strip(),
                        "source_type": "resume", "fact_status": ftype})

    add("summary", "", p.get("summary", ""))
    for e in p.get("education", []):
        add("education", e[:60], e)
    if p.get("skills"):
        add("skills", "skills", ", ".join(p["skills"]))
    for sec in ("experience", "projects"):
        for it in p.get(sec, []):
            body = " ".join(b if b.endswith((".", "!", "?")) else b + "." for b in it["bullets"])
            add(sec, it["name"], body or it["name"])
    for c in p.get("certifications", []):
        add("certifications", c[:60], c)
    for a in p.get("achievements", []):
        add("achievements", a[:60], a)
    return out
