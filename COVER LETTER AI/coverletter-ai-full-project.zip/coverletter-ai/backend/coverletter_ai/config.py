import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


@dataclass
class Settings:
    data_dir: Path = ROOT / "storage"
    web_dir: Path = ROOT / "web"
    host: str = "127.0.0.1"          # loopback by default; never expose without a token
    port: int = 8787
    max_upload_mb: int = 20
    offline: bool = True              # network kill switch (default ON)
    token: str = ""                   # optional bearer token (desktop bridge / mobile)
    provider: str = "auto"            # auto | ollama | template
    ollama_url: str = "http://127.0.0.1:11434"
    ollama_model: str = "qwen2.5:7b-instruct"
    temperature: float = 0.35
    top_p: float = 0.9
    rate_limit_per_min: int = 240
    mcp_origins: str = ""            # extra allowed Origin hostnames for /mcp (comma separated)
    prompt_version: str = "gen-v1"
    chunking_version: str = "chunk-v1"

    @classmethod
    def from_env(cls) -> "Settings":
        s = cls()
        e = os.environ.get
        s.data_dir = Path(e("DATABASE_DIR", str(s.data_dir)))
        s.host = e("APP_HOST", s.host)
        s.port = int(e("APP_PORT", s.port))
        s.token = e("COVERLETTER_TOKEN", "")
        s.provider = e("AI_PROVIDER", s.provider)
        s.ollama_url = e("OLLAMA_URL", s.ollama_url)
        s.ollama_model = e("OLLAMA_MODEL", s.ollama_model)
        s.max_upload_mb = int(e("MAX_UPLOAD_MB", s.max_upload_mb))
        s.offline = e("OFFLINE", "1") != "0"
        s.mcp_origins = e("MCP_ALLOWED_ORIGINS", "")
        return s
