"""Skill lexicon + text helpers shared by parsing, RAG, evidence and validation."""
import re

# canonical, display, category, aliases
_DEFS = [
    ("python", "Python", "tech", ["python"]),
    ("sql", "SQL", "tech", ["sql"]),
    ("mysql", "MySQL", "tech", ["mysql"]),
    ("postgresql", "PostgreSQL", "tech", ["postgresql", "postgres"]),
    ("mongodb", "MongoDB", "tech", ["mongodb"]),
    ("excel", "Excel", "tool", ["excel", "microsoft excel", "ms excel"]),
    ("power_bi", "Power BI", "tool", ["power bi", "powerbi", "power-bi"]),
    ("tableau", "Tableau", "tool", ["tableau"]),
    ("looker", "Looker", "tool", ["looker"]),
    ("git", "Git", "tool", ["git", "github", "gitlab"]),
    ("jira", "Jira", "tool", ["jira"]),
    ("docker", "Docker", "tool", ["docker"]),
    ("kubernetes", "Kubernetes", "tool", ["kubernetes", "k8s"]),
    ("aws", "AWS", "cloud", ["aws", "amazon web services"]),
    ("azure", "Azure", "cloud", ["azure"]),
    ("gcp", "GCP", "cloud", ["gcp", "google cloud"]),
    ("java", "Java", "tech", ["java"]),
    ("javascript", "JavaScript", "tech", ["javascript"]),
    ("typescript", "TypeScript", "tech", ["typescript"]),
    ("react", "React", "tech", ["react", "react.js", "reactjs"]),
    ("nodejs", "Node.js", "tech", ["node.js", "nodejs"]),
    ("cpp", "C++", "tech", ["c++"]),
    ("csharp", "C#", "tech", ["c#"]),
    ("golang", "Go", "tech", ["golang"]),
    ("html", "HTML", "tech", ["html"]),
    ("css", "CSS", "tech", ["css"]),
    ("fastapi", "FastAPI", "tech", ["fastapi"]),
    ("django", "Django", "tech", ["django"]),
    ("flask", "Flask", "tech", ["flask"]),
    ("pandas", "Pandas", "tech", ["pandas"]),
    ("numpy", "NumPy", "tech", ["numpy"]),
    ("scikit", "scikit-learn", "tech", ["scikit-learn", "sklearn"]),
    ("tensorflow", "TensorFlow", "tech", ["tensorflow"]),
    ("pytorch", "PyTorch", "tech", ["pytorch"]),
    ("machine_learning", "machine learning", "domain", ["machine learning"]),
    ("nlp", "NLP", "domain", ["nlp", "natural language processing"]),
    ("rag", "RAG", "domain", ["rag", "retrieval augmented generation", "retrieval-augmented generation"]),
    ("data_analysis", "data analysis", "domain", ["data analysis", "data analytics", "analyzing data", "analysing data"]),
    ("data_visualization", "data visualization", "domain", ["data visualization", "data visualisation"]),
    ("dashboards", "dashboards", "domain", ["dashboard", "dashboards", "dashboarding"]),
    ("reporting", "reporting", "domain", ["reporting", "reports"]),
    ("etl", "ETL", "domain", ["etl"]),
    ("statistics", "statistics", "domain", ["statistics", "statistical analysis"]),
    ("a_b_testing", "A/B testing", "domain", ["a/b testing", "ab testing"]),
    ("agile", "Agile", "domain", ["agile", "scrum"]),
    ("rest_api", "REST APIs", "tech", ["rest api", "rest apis", "restful"]),
    ("linux", "Linux", "tech", ["linux"]),
    ("communication", "communication", "soft", ["communication", "communicating"]),
    ("teamwork", "teamwork", "soft", ["teamwork", "team player", "collaboration", "collaborating"]),
    ("leadership", "leadership", "soft", ["leadership"]),
    ("problem_solving", "problem solving", "soft", ["problem solving", "problem-solving"]),
    ("stakeholder", "stakeholder management", "soft", ["stakeholder management"]),
    ("presentation", "presentation", "soft", ["presentation skills", "presenting"]),
    ("attention_detail", "attention to detail", "soft", ["attention to detail", "detail-oriented"]),
]

BY_CANON = {c: (d, cat) for c, d, cat, _ in _DEFS}
ALIAS = {a: c for c, _, _, al in _DEFS for a in al}
_ALIAS_RE = re.compile(
    r"(?<![\w+#])(" + "|".join(re.escape(a) for a in sorted(ALIAS, key=len, reverse=True)) + r")(?![\w+#])",
    re.IGNORECASE,
)


def find_skills(text: str) -> dict:
    """canonical -> count, for every lexicon skill mentioned in text."""
    out: dict = {}
    for m in _ALIAS_RE.finditer(text or ""):
        c = ALIAS[m.group(1).lower()]
        out[c] = out.get(c, 0) + 1
    return out


def display(canon: str) -> str:
    return BY_CANON.get(canon, (canon, ""))[0]


def category(canon: str) -> str:
    return BY_CANON.get(canon, ("", ""))[1]


def canon_text(text: str) -> str:
    return _ALIAS_RE.sub(lambda m: " skill" + ALIAS[m.group(1).lower()].replace("_", "") + " ", text or "")


STOP = set("""a an and are as at be been but by for from has have had he her his i if in into is it its
me my of on or our that the their them then there these they this to us was we were will with would you
your not can could should may also than so such very more most other any all each both been being do does
did done just over under about between through during before after above below up down out off again further
once here when where why how what which who whom whose while""".split())


def stem(w: str) -> str:
    for suf in ("ing", "ed", "es", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            return w[: -len(suf)]
    return w


def words(text: str) -> list:
    return re.findall(r"[a-z0-9][a-z0-9+#.]*[a-z0-9+#]|[a-z0-9]", (text or "").lower())


def content_stems(text: str) -> set:
    return {stem(w.strip(".")) for w in words(text) if w not in STOP and len(w) > 2}


def sentences(text: str) -> list:
    parts = re.split(r"(?<=[.!?])\s+(?=[A-Z\"'(])", (text or "").strip())
    return [p.strip() for p in parts if p.strip()]
