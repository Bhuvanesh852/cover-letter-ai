"""Safe file -> text extraction (PDF / DOCX / TXT / MD) with quality reporting."""
import io
import re
import zipfile
import xml.etree.ElementTree as ET


class ParseError(Exception):
    """Message is safe to show to end users (no stack traces)."""


W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _docx_text(data: bytes) -> str:
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
        if sum(i.file_size for i in z.infolist()) > 100 * 1024 * 1024:  # zip-bomb guard
            raise ParseError("The DOCX file is unexpectedly large and was rejected.")
        root = ET.fromstring(z.read("word/document.xml"))
    except (zipfile.BadZipFile, KeyError, ET.ParseError):
        raise ParseError("The DOCX file could not be read. Try re-saving it as DOCX or PDF.")
    lines = []
    for p in root.iter(W + "p"):
        t = "".join(n.text or "" for n in p.iter(W + "t")).strip()
        if not t:
            continue
        bullet = p.find(f"{W}pPr/{W}numPr") is not None
        lines.append(("- " + t) if bullet else t)
    return "\n".join(lines)


def _pdf_text(data: bytes):
    try:
        from pypdf import PdfReader
    except ImportError:
        raise ParseError("PDF support needs the optional 'pypdf' package (pip install pypdf), "
                         "or upload DOCX/TXT instead.")
    try:
        r = PdfReader(io.BytesIO(data))
        if r.is_encrypted:
            raise ParseError("This PDF is password-protected. Remove the password and upload it again.")
        pages = [(p.extract_text() or "") for p in r.pages]
    except ParseError:
        raise
    except Exception:
        raise ParseError("The PDF could not be parsed. Try a text-based PDF or a DOCX file.")
    return "\n".join(pages), len(pages)


def extract_text(filename: str, data: bytes, max_mb: int = 20) -> dict:
    if len(data) > max_mb * 1024 * 1024:
        raise ParseError(f"File is larger than the {max_mb} MB limit.")
    if not data:
        raise ParseError("The file is empty.")
    ext = (filename.rsplit(".", 1)[-1] if "." in filename else "txt").lower()
    warnings, pages = [], 1
    if ext == "pdf":
        if not data.startswith(b"%PDF"):
            raise ParseError("This file is not a valid PDF.")
        text, pages = _pdf_text(data)
        if len(text.strip()) < 50:
            warnings.append("Very little text was found - this may be a scanned PDF. Local OCR is not enabled.")
    elif ext == "docx":
        if not data.startswith(b"PK"):
            raise ParseError("This file is not a valid DOCX.")
        text = _docx_text(data)
    elif ext in ("txt", "md", "markdown", "text"):
        for enc in ("utf-8-sig", "utf-16", "latin-1"):
            try:
                text = data.decode(enc)
                break
            except UnicodeError:
                continue
    else:
        raise ParseError(f"Unsupported file type '.{ext}'. Use PDF, DOCX, TXT or Markdown.")
    text = clean(text)
    if not text.strip():
        raise ParseError("No readable text was found in this file.")
    quality = "High"
    if len(text) < 300 or warnings:
        quality = "Needs review"
    return {"text": text, "pages": pages, "kind": ext, "quality": quality, "warnings": warnings}


def clean(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()
