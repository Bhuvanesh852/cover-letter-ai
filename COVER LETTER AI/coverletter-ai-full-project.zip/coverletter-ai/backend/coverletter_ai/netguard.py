"""Network kill switch.

When enabled, any attempt to open a non-loopback connection or resolve a
non-local hostname raises NetworkBlocked and is recorded. This makes the
"no HTTP call is made in offline mode" guarantee *testable* (see tests).
"""
import ipaddress
import socket

_orig_connect = socket.socket.connect
_orig_gai = socket.getaddrinfo
_active = False
blocked_attempts: list[str] = []


class NetworkBlocked(OSError):
    pass


def _is_local(host) -> bool:
    if host in ("localhost", "", None):
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _connect(self, address):
    if _active and isinstance(address, tuple) and not _is_local(address[0]):
        blocked_attempts.append(str(address[0]))
        raise NetworkBlocked(f"Network disabled (offline mode): {address[0]}")
    return _orig_connect(self, address)


def _gai(host, *a, **kw):
    if _active and not _is_local(host):
        blocked_attempts.append(str(host))
        raise NetworkBlocked(f"Network disabled (offline mode): {host}")
    return _orig_gai(host, *a, **kw)


def enable():
    global _active
    _active = True
    socket.socket.connect = _connect
    socket.getaddrinfo = _gai


def disable():
    global _active
    _active = False


def is_active() -> bool:
    return _active
