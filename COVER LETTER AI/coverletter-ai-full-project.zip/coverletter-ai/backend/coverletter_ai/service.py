"""Application service layer: everything the HTTP API (or a future CLI/mobile bridge) can do."""
import hashlib
import json
import re
from pathlib import Path
from . import netguard, knowledge as K
from .config import Settings
from .db import DB, uid, now
from .documents_ import parse_upload
from .evidence import build_evidence
from .generator import Generator
from .jobs import analyze_job
from .llm import pick_provider
from .mcp import McpRouter
from .profile import extract_profile, profile_to_items
from .rag import RagStore
from .aisvc import AIMixin
from .errors import NotFound, BadRequest
from .cloud import PROVIDERS, Secrets
import copy
from collections import OrderedDict
from .validator import Validator, style_report

STATUSES = ["Saved", "Draft", "Applied", "Interview", "Rejected", "Offer", "Archived"]
PROFILE_FIELDS = {"name": str, "email": str, "phone": str, "location": str, "summary": str, "education": list,
                  "skills": list, "experience": list, "projects": list, "certifications": list, "achievements": list}
CLICHE_SWAPS = {r"\bpassionate about\b": "interested in", r"\bhighly motivated individual\b": "motivated candidate",
                r"\bthrilled to\b": "glad to", r"\bdynamic\b": ""}




class App(AIMixin):
    def __init__(self, settings: Settings = None, provider=None):
        self.s = settings or Settings.from_env()
        self.s.data_dir.mkdir(parents=True, exist_ok=True)
        self.db = DB(self.s.data_dir / "coverletter.db")
        self.rag = RagStore(self.db)
        self._pick_local = lambda: provider or pick_provider(self.s)
        self.local = self._pick_local()
        self.registry = copy.deepcopy(PROVIDERS)
        self.secrets = Secrets(self.s.data_dir / "secrets.json")
        self._cache = OrderedDict()
        self.mcp = McpRouter(self.db, self.s.data_dir, lambda: not self.s.offline)
        cb = self._ai().get("custom_base")
        if cb: self.registry["custom"]["base"] = cb
        saved = self.db.one("SELECT value FROM settings WHERE key='offline'")
        if saved: self.s.offline = saved["value"] == "1"
        self._apply_network()

    # ---- network / health ----
    def _apply_network(self):
        netguard.enable() if self.s.offline else netguard.disable()

    def set_offline(self, flag: bool):
        self.s.offline = bool(flag)
        self.db.x("INSERT OR REPLACE INTO settings VALUES('offline',?)", ("1" if flag else "0",))
        self.db.audit("network_mode", {"offline": bool(flag)}); self._apply_network()
        return self.health()

    def health(self):
        prov, reason = self._resolve()
        eff = prov or self.local
        return {"status": "ok", "mode": "OFFLINE AI" if self.s.offline else "ONLINE (cloud/connectors allowed)",
                "offline": self.s.offline, "model": {"model": eff.name, "ok": True} if eff.kind != "slm" else self.local.health_check(),
                "model_kind": eff.kind, "engine_reason": reason, "selected": self._ai()["provider"],
                "rag": self.rag.versions(), "storage": "local", "blocked_network_attempts": len(netguard.blocked_attempts)}

    # ---- candidates ----
    def _cand(self, cid) -> dict:
        r = self.db.one("SELECT * FROM candidates WHERE id=?", (cid,))
        if not r: raise NotFound("Profile not found.")
        r["profile"] = json.loads(r.pop("profile_json")); return r

    def create_candidate(self, filename="resume.txt", data: bytes = None, text: str = None, name="", demo=False):
        if data is not None:
            parsed = parse_upload(filename, data, self.s.max_upload_mb)
        elif text and text.strip():
            parsed = parse_upload("pasted.txt", text.encode(), self.s.max_upload_mb)
        else:
            raise BadRequest("Provide a resume file or paste resume text.")
        prof = extract_profile(parsed["text"], name)
        warns = list(parsed["warnings"])
        if not prof["name"]: warns.append("Name not detected - please add it in the profile review.")
        if not prof["skills"] and not prof["projects"] and not prof["experience"]:
            warns.append("No skills, projects or experience sections were detected. Check headings or edit the profile.")
            parsed["quality"] = "Needs review"
        cid = uid("cand")
        self.db.x("INSERT INTO candidates VALUES(?,?,?,?,?,?)", (cid, prof["name"] or "Unnamed", json.dumps(prof), int(demo), now(), now()))
        did = uid("doc")
        self.db.x("INSERT INTO documents VALUES(?,?,?,?,?,?,?,?,?,?)", (did, cid, filename, parsed["kind"],
                  hashlib.sha256(parsed["text"].encode()).hexdigest(), len(parsed["text"]), parsed["pages"],
                  parsed["quality"], parsed["text"], now()))
        idx = self.rag.sync_candidate(cid, profile_to_items(prof), did)
        self.db.audit("candidate_created", {"id": cid, "quality": parsed["quality"]})
        return {"id": cid, "profile": prof, "import": {"filename": filename, "type": parsed["kind"], "pages": parsed["pages"],
                "chars": len(parsed["text"]), "quality": parsed["quality"], "warnings": warns}, "index": idx}

    def list_candidates(self):
        return [{"id": r["id"], "name": r["name"], "is_demo": bool(r["is_demo"])}
                for r in self.db.q("SELECT id,name,is_demo FROM candidates ORDER BY created_at DESC")]

    def get_candidate(self, cid):
        c = self._cand(cid)
        chunks = self.db.q("SELECT id,section,subsection,text,origin,fact_status,use_state FROM chunks WHERE candidate_id=?", (cid,))
        return {"id": cid, "name": c["name"], "is_demo": bool(c["is_demo"]), "profile": c["profile"], "chunks": chunks}

    def update_profile(self, cid, changes: dict):
        c = self._cand(cid); p = c["profile"]
        for k, v in changes.items():
            if k not in PROFILE_FIELDS or not isinstance(v, PROFILE_FIELDS[k]):
                raise BadRequest(f"Invalid profile field '{k}'.")
            p[k] = v
        self.db.x("UPDATE candidates SET name=?, profile_json=?, updated_at=? WHERE id=?", (p["name"] or "Unnamed", json.dumps(p), now(), cid))
        return {"profile": p, "index": self.rag.sync_candidate(cid, profile_to_items(p))}  # only changed chunks re-embedded

    def add_evidence(self, cid, section, subsection, text):
        self._cand(cid)
        if section not in ("projects", "experience", "achievements", "skills", "certifications") or not text.strip():
            raise BadRequest("Provide a valid section and text.")
        return {"chunk_id": self.rag.add_user_evidence(cid, section, subsection, text.strip()[:2000]), "fact_status": "user_added"}

    def set_chunk_state(self, chunk_id, state):
        if state not in ("use", "do_not_use", "needs_review"): raise BadRequest("Invalid state.")
        row = self.db.one("SELECT candidate_id FROM chunks WHERE id=?", (chunk_id,))
        self.db.x("UPDATE chunks SET use_state=? WHERE id=?", (state, chunk_id))
        if row: self.rag.invalidate(row["candidate_id"])
        return {"ok": True}

    # ---- jobs ----
    def analyze_job(self, cid, text, title="", company="", company_description="", company_source="USER PROVIDED"):
        cand = self._cand(cid)
        if not text or not text.strip(): raise BadRequest("Paste a job description to start personalization.")
        if len(text) > 60000: raise BadRequest("Job description is too long.")
        job = analyze_job(text, title, company)
        comp_text, comp_warn = "", []
        if company_description:
            from .jobs import screen
            comp_text, comp_warn = screen(company_description[:8000])
        job["company_info"] = {"name": job["company"], "description": comp_text.strip(), "source_label": company_source}
        job["warnings"] += comp_warn
        dup = self.db.one("SELECT id FROM jobs WHERE candidate_id=? AND desc_hash=?", (cid, job["desc_hash"]))
        jid = uid("job")
        self.db.x("INSERT INTO jobs VALUES(?,?,?,?,?,?,?)", (jid, cid, job["title"], job["company"], job["desc_hash"], json.dumps(job), now()))
        ev = build_evidence(self.rag, cand, job, job["company_info"])
        return {"job_id": jid, "job": {k: v for k, v in job.items() if k != "clean_text"}, "evidence": ev,
                "duplicate_of": dup["id"] if dup else None}

    def _job(self, jid):
        r = self.db.one("SELECT * FROM jobs WHERE id=?", (jid,))
        if not r: raise NotFound("Job not found.")
        return json.loads(r["job_json"])

    # ---- letters ----
    def _save_letter(self, cid, jid, content, report, style, meta, parent=None):
        ver = (self.db.one("SELECT MAX(version) v FROM letters WHERE job_id=?", (jid,)) or {}).get("v") or 0
        lid = uid("let")
        self.db.x("INSERT INTO letters VALUES(?,?,?,?,?,?,?,?,?)", (lid, cid, jid, ver + 1, parent, json.dumps(content),
                  json.dumps({"report": report, "style": style}), json.dumps(meta), now()))
        return lid

    def get_letter(self, lid):
        r = self.db.one("SELECT * FROM letters WHERE id=?", (lid,))
        if not r: raise NotFound("Letter not found.")
        r.update(content=json.loads(r.pop("content_json")), validation=json.loads(r.pop("validation_json")), meta=json.loads(r.pop("meta_json")))
        return r

    def list_letters(self, cid=None):
        q = "SELECT l.id,l.version,l.job_id,l.created_at,j.title,j.company FROM letters l JOIN jobs j ON j.id=l.job_id"
        return self.db.q(q + (" WHERE l.candidate_id=?" if cid else "") + " ORDER BY l.rowid DESC", (cid,) if cid else ())

    def _validator(self, cid, jid):
        cand, job = self._cand(cid), self._job(jid)
        ev = build_evidence(self.rag, cand, job, job["company_info"])
        v = Validator(self.rag.active_chunks(cid), set(ev["pack"]["allowed_skills"]), job["company_info"]["description"],
                      job.get("company", ""), job.get("clean_text", ""), cand["profile"].get("name", ""))
        return v, job

    def validate(self, lid, paragraphs=None):
        L = self.get_letter(lid); v, job = self._validator(L["candidate_id"], L["job_id"])
        paras = paragraphs if paragraphs is not None else L["content"]["paragraphs"]
        rep = v.check(paras)
        return {"report": rep, "style": style_report(paras, rep, job)}

    def save_edit(self, lid, paragraphs, explain=None):
        """User edits are re-validated and stored as a new version (history is never overwritten)."""
        L = self.get_letter(lid)
        if not isinstance(paragraphs, list) or not all(isinstance(p, str) for p in paragraphs): raise BadRequest("Invalid paragraphs.")
        v = self.validate(lid, paragraphs)
        content = {"header": L["content"]["header"], "paragraphs": paragraphs}
        meta = {**L["meta"], "edited": True, "explain": explain or []}
        nid = self._save_letter(L["candidate_id"], L["job_id"], content, v["report"], v["style"], meta, L["id"])
        return {"letter_id": nid, **v, "content": content}

    def rewrite(self, lid, action):
        L = self.get_letter(lid); v, job = self._validator(L["candidate_id"], L["job_id"])
        paras = L["content"]["paragraphs"]; rep = v.check(paras); changes = []
        if action == "remove_unsupported":
            new = v.sanitize(rep)
            changes = [{"before": s["text"], "after": "(removed)", "why": "; ".join(s["issues"])}
                       for ss in rep["paragraphs"] for s in ss if s["label"] == "UNSUPPORTED"]
        elif action == "more_concise":
            new = []
            for i, ss in enumerate(rep["paragraphs"]):
                keep = ss if i in (0, len(rep["paragraphs"]) - 1) else ss[:2]
                changes += [{"before": s["text"], "after": "(removed)", "why": "kept the strongest two sentences"} for s in ss[2:] if i not in (0, len(rep["paragraphs"]) - 1)]
                new.append(" ".join(s["text"] for s in keep))
        elif action == "naturalize":
            new = []
            for p in paras:
                q = p
                for rx, sub in CLICHE_SWAPS.items(): q = re.sub(rx, sub, q, flags=re.I)
                q = re.sub(r"\s{2,}", " ", q).strip()
                if q != p: changes.append({"before": p[:120], "after": q[:120], "why": "replaced a generic AI-style phrase"})
                new.append(q)
        else:
            raise BadRequest("Unknown rewrite action.")
        return self.save_edit(lid, new, changes) | {"changes": changes}

    def export(self, lid, fmt, template="ats-minimal"):
        from .exporter import export
        L = self.get_letter(lid)
        return export(L["content"], fmt, template)

    # ---- applications ----
    def list_applications(self, cid=None):
        return self.db.q("SELECT * FROM applications" + (" WHERE candidate_id=?" if cid else "") + " ORDER BY updated_at DESC", (cid,) if cid else ())

    def save_application(self, data: dict, aid=None):
        if data.get("status", "Saved") not in STATUSES: raise BadRequest("Invalid status.")
        cols = ["candidate_id", "job_id", "letter_id", "company", "role", "url", "location", "status", "applied_date", "followup_date", "notes"]
        if aid is None:
            self._cand(data.get("candidate_id"))
            aid = uid("app")
            self.db.x("INSERT INTO applications VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (aid, *[str(data.get(c, "") or "") if c != "status" else data.get(c, "Saved") for c in cols], now(), now()))
        else:
            for c in cols[1:]:
                if c in data: self.db.x(f"UPDATE applications SET {c}=?, updated_at=? WHERE id=?", (str(data[c]), now(), aid))
        return self.db.one("SELECT * FROM applications WHERE id=?", (aid,))

    # ---- privacy ----
    def delete_candidate(self, cid):
        self._cand(cid)
        self.db.x("DELETE FROM candidates WHERE id=?", (cid,)); self.rag.invalidate(cid)   # ON DELETE CASCADE removes docs, chunks, vectors, jobs, letters, apps
        self.db.audit("candidate_deleted", {"id": cid}); self.db.x("VACUUM"); return {"deleted": cid}

    def delete_all(self):
        for t in ("candidates", "settings", "mcp_permissions"): self.db.x(f"DELETE FROM {t}")
        self.rag.invalidate(); self.secrets.mem.clear(); self._cache.clear()
        if self.secrets.path.exists(): self.secrets.path.unlink()
        self.db.audit("all_data_deleted"); self.db.x("VACUUM"); return {"deleted": "all"}

    def audit_log(self, n=100):
        return self.db.q("SELECT ts,event,detail,network_used FROM audit_events ORDER BY id DESC LIMIT ?", (n,))

    def load_demo(self):
        d = Path(__file__).resolve().parents[2] / "demo"
        c = self.create_candidate("demo_resume.md", (d / "resume.md").read_bytes(), demo=True)
        j = self.analyze_job(c["id"], (d / "job.txt").read_text(), company_description=(d / "company.txt").read_text())
        return {"candidate": c, "job": j}
