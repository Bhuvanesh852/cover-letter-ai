"""Zero-dependency HTTP API + static web UI (stdlib only). Binds to loopback by default."""
import base64
import hmac
import json
import re
import sys
import time
from collections import defaultdict, deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from .mcp import ToolError, NetworkDisabled
from .mcp_server import McpServer
from .parsing import ParseError
from .service import App, BadRequest, NotFound

MIME = {".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".json": "application/json"}


def need(d: dict, *keys):
    miss = [k for k in keys if d.get(k) in (None, "")]
    if miss: raise BadRequest("Missing required field(s): " + ", ".join(miss))


def routes(app: App):
    R = []
    def r(method, pattern):
        def deco(fn): R.append((method, re.compile("^" + pattern + "$"), fn)); return fn
        return deco
    @r("GET", "/api/health")
    def _(m, q, b): return app.health()
    @r("GET", "/api/candidates")
    def _(m, q, b): return app.list_candidates()
    @r("POST", "/api/candidates")
    def _(m, q, b):
        data = None
        if b.get("content_b64"):
            try: data = base64.b64decode(b["content_b64"], validate=True)
            except Exception: raise BadRequest("The uploaded file could not be decoded.")
        return app.create_candidate(b.get("filename", "resume.txt"), data, b.get("text"), b.get("name", ""))
    @r("GET", "/api/candidates/([\\w-]+)")
    def _(m, q, b): return app.get_candidate(m[1])
    @r("DELETE", "/api/candidates/([\\w-]+)")
    def _(m, q, b): return app.delete_candidate(m[1])
    @r("PUT", "/api/candidates/([\\w-]+)/profile")
    def _(m, q, b): return app.update_profile(m[1], b)
    @r("POST", "/api/candidates/([\\w-]+)/evidence")
    def _(m, q, b): need(b, "section", "text"); return app.add_evidence(m[1], b["section"], b.get("subsection", ""), b["text"])
    @r("PATCH", "/api/chunks/([\\w-]+)")
    def _(m, q, b): need(b, "state"); return app.set_chunk_state(m[1], b["state"])
    @r("POST", "/api/jobs/analyze")
    def _(m, q, b):
        need(b, "candidate_id", "text")
        return app.analyze_job(b["candidate_id"], b["text"], b.get("title", ""), b.get("company", ""), b.get("company_description", ""))
    @r("POST", "/api/letters/generate")
    def _(m, q, b): need(b, "candidate_id", "job_id"); return app.generate(b["candidate_id"], b["job_id"], b.get("options"))
    @r("GET", "/api/letters")
    def _(m, q, b): return app.list_letters((q.get("candidate_id") or [None])[0])
    @r("GET", "/api/letters/([\\w-]+)")
    def _(m, q, b): return app.get_letter(m[1])
    @r("POST", "/api/letters/([\\w-]+)/validate")
    def _(m, q, b): return app.validate(m[1], b.get("paragraphs"))
    @r("POST", "/api/letters/([\\w-]+)/save")
    def _(m, q, b): need(b, "paragraphs"); return app.save_edit(m[1], b["paragraphs"])
    @r("POST", "/api/letters/([\\w-]+)/rewrite")
    def _(m, q, b): need(b, "action"); return app.rewrite(m[1], b["action"])
    @r("GET", "/api/letters/([\\w-]+)/export")
    def _(m, q, b):
        try: return ("FILE", *app.export(m[1], (q.get("format") or ["pdf"])[0], (q.get("template") or ["ats-minimal"])[0]))
        except ValueError as e: raise BadRequest(str(e))
    @r("GET", "/api/applications")
    def _(m, q, b): return app.list_applications((q.get("candidate_id") or [None])[0])
    @r("POST", "/api/applications")
    def _(m, q, b): return app.save_application(b)
    @r("PUT", "/api/applications/([\\w-]+)")
    def _(m, q, b): return app.save_application(b, m[1])
    @r("GET", "/api/mcp/servers")
    def _(m, q, b): return app.mcp.list_servers()
    @r("POST", "/api/mcp/permission")
    def _(m, q, b): need(b, "connector", "permission"); app.mcp.set_permission(b["connector"], b["permission"]); return app.mcp.list_servers()
    @r("POST", "/api/mcp/call")
    def _(m, q, b): need(b, "connector", "tool"); return app.mcp.call(b["connector"], b["tool"], b.get("arguments", {}), bool(b.get("confirmed")))
    @r("POST", "/api/settings/network")
    def _(m, q, b): return app.set_offline(bool(b.get("offline", True)))
    @r("GET", "/api/ai")
    def _(m, q, b): return app.ai_status()
    @r("POST", "/api/ai")
    def _(m, q, b): return app.ai_set(b)
    @r("GET", "/api/ai/models")
    def _(m, q, b):
        need({"p": (q.get("provider") or [""])[0]}, "p")
        return app.ai_models(q["provider"][0], (q.get("free") or ["0"])[0] == "1")
    @r("POST", "/api/ai/test")
    def _(m, q, b): need(b, "provider"); return app.ai_test(b["provider"])
    @r("POST", "/api/ai/preview")
    def _(m, q, b): need(b, "candidate_id", "job_id"); return app.ai_preview(b["candidate_id"], b["job_id"], b.get("options"))
    @r("POST", "/api/letters/variants")
    def _(m, q, b): need(b, "candidate_id", "job_id"); return app.variants(b["candidate_id"], b["job_id"], b.get("options"))
    @r("POST", "/api/letters/([\\w-]+)/email")
    def _(m, q, b): return app.email_draft(m[1])
    @r("GET", "/api/jobs/([\\w-]+)/interview")
    def _(m, q, b):
        need({"c": (q.get("candidate_id") or [""])[0]}, "c")
        return app.interview_prep(q["candidate_id"][0], m[1])
    @r("POST", "/api/batch")
    def _(m, q, b): need(b, "candidate_id", "jobs"); return app.batch(b["candidate_id"], b["jobs"], b.get("options"))
    @r("POST", "/api/batch/export")
    def _(m, q, b):
        need(b, "letter_ids")
        from .exporter import MIMES
        return ("FILE", app.batch_zip(b["letter_ids"], tuple(b.get("formats", ("pdf", "docx", "txt"))), b.get("template", "ats-minimal")), MIMES["zip"], "cover_letters.zip")
    @r("POST", "/api/convert/text")
    def _(m, q, b):
        from .parsing import extract_text
        try: data = base64.b64decode(b.get("content_b64", ""), validate=True)
        except Exception: raise BadRequest("The uploaded file could not be decoded.")
        out = extract_text(b.get("filename", "file.txt"), data, app.s.max_upload_mb)
        return {"text": out["text"], "pages": out["pages"], "warnings": out["warnings"]}
    @r("GET", "/api/audit")
    def _(m, q, b): return app.audit_log()
    @r("POST", "/api/demo")
    def _(m, q, b): return app.load_demo()
    @r("POST", "/api/data/delete_all")
    def _(m, q, b):
        if b.get("confirm") != "DELETE": raise BadRequest('Send {"confirm": "DELETE"} to delete all local data.')
        return app.delete_all()
    return R


def make_server(app: App, host=None, port=None):
    R, hits = routes(app), defaultdict(deque)
    mcp_srv = McpServer(app)
    OK_HOSTS = {"claude.ai", "www.claude.ai", "claude.com", "www.claude.com", "localhost", "127.0.0.1"} | {h.strip() for h in app.s.mcp_origins.split(",") if h.strip()}
    web = app.s.web_dir.resolve()
    max_body = int(app.s.max_upload_mb * 1024 * 1024 * 1.4) + 4096

    class H(BaseHTTPRequestHandler):
        server_version = "CoverLetterAI"
        protocol_version = "HTTP/1.1"   # keep-alive: fewer connections for the UI
        def log_message(self, *a): pass       # never log request bodies / resume text

        def _send(self, code, body: bytes, ctype="application/json", extra=None):
            self.send_response(code)
            self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff"); self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'")
            for k, v in (extra or {}).items(): self.send_header(k, v)
            self.end_headers(); self.wfile.write(body)

        def _json(self, code, obj): self._send(code, json.dumps(obj, default=str).encode())

        def _limited(self):
            ip, q, now = self.client_address[0], hits[self.client_address[0]], time.time()
            while q and now - q[0] > 60: q.popleft()
            q.append(now); return len(q) > app.s.rate_limit_per_min

        def _handle(self, method):
            u = urlparse(self.path); qs = parse_qs(u.query)
            try:
                n = int(self.headers.get("Content-Length") or 0)
                if n > max_body:
                    self.close_connection = True            # don't read an oversized body
                    return self._json(413, {"error": "Request is too large."})
                raw = self.rfile.read(n) if n else b""       # always drain the body (keep-alive safety)
                if self._limited(): return self._json(429, {"error": "Too many requests. Please slow down."})
                if u.path == "/mcp" or u.path.startswith("/mcp/"):
                    return self._mcp(method, u.path, raw)
                if not u.path.startswith("/api/"):
                    return self._static(u.path) if method == "GET" else self._json(404, {"error": "Not found."})
                if app.s.token and self.headers.get("Authorization") != f"Bearer {app.s.token}":
                    return self._json(401, {"error": "Authentication required."})
                body = {}
                if raw:
                    try: body = json.loads(raw)
                    except ValueError: return self._json(400, {"error": "Request body must be valid JSON."})
                    if not isinstance(body, dict): return self._json(400, {"error": "Request body must be a JSON object."})
                for mth, rx, fn in R:
                    m = rx.match(u.path)
                    if mth == method and m:
                        out = fn(m, qs, body)
                        if isinstance(out, tuple) and out[0] == "FILE":
                            _, data, mime, name = out
                            return self._send(200, data, mime, {"Content-Disposition": f'attachment; filename="{name}"'})
                        return self._json(200, out)
                self._json(404, {"error": "Not found."})
            except NotFound as e: self._json(404, {"error": str(e)})
            except NetworkDisabled as e: self._json(403, {"error": str(e)})
            except (BadRequest, ParseError, ToolError) as e: self._json(400, {"error": str(e)})
            except Exception as e:                         # no stack traces for users; type only to stderr
                print(f"[error] {type(e).__name__} on {method} {u.path}", file=sys.stderr)
                app.db.audit("server_error", {"type": type(e).__name__, "path": u.path})
                self._json(500, {"error": "Something went wrong. Check AI diagnostics or try again."})

        def _mcp(self, method, path, raw):
            """MCP Streamable HTTP endpoint. Auth: Authorization: Bearer <token>  OR  /mcp/<token> (for UIs that only accept a URL)."""
            local = app.s.host in ("127.0.0.1", "localhost", "::1")
            if app.s.token or not local:
                given = [path[5:].strip("/")] + [(self.headers.get("Authorization") or "")[7:]]
                if not app.s.token or not any(g and hmac.compare_digest(g.encode(), app.s.token.encode()) for g in given):
                    return self._json(401, {"error": "Authentication required. Set COVERLETTER_TOKEN and use /mcp/<token> or a Bearer header."})
            origin = self.headers.get("Origin")
            if origin and (urlparse(origin).hostname or "") not in OK_HOSTS:
                return self._json(403, {"error": "Origin not allowed."})           # DNS-rebinding / browser-abuse protection
            if method != "POST":
                return self._send(405, b'{"error":"Use POST."}', extra={"Allow": "POST"})
            try: msg = json.loads(raw)
            except ValueError:
                return self._json(400, {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}})
            resp = mcp_srv.handle(msg)
            if resp is None: return self._send(202, b"", "text/plain")             # notifications / responses
            self._json(200, resp)

        def _static(self, path):
            rel = "index.html" if path in ("/", "") else path.lstrip("/")
            f = (web / rel).resolve()
            if web not in f.parents and f != web or not f.is_file():
                return self._json(404, {"error": "Not found."})
            self._send(200, f.read_bytes(), MIME.get(f.suffix, "application/octet-stream"))

        def do_GET(self): self._handle("GET")
        def do_POST(self): self._handle("POST")
        def do_PUT(self): self._handle("PUT")
        def do_PATCH(self): self._handle("PATCH")
        def do_DELETE(self): self._handle("DELETE")

    return ThreadingHTTPServer((host or app.s.host, app.s.port if port is None else port), H)


def main():
    app = App()
    srv = make_server(app)
    h = app.health()
    print(f"CoverLetter AI on http://{app.s.host}:{srv.server_address[1]}  |  {h['mode']}  |  model: {h['model'].get('model')} ({h['model_kind']})")
    if app.s.host not in ("127.0.0.1", "localhost") and not app.s.token:
        print("WARNING: listening beyond loopback without COVERLETTER_TOKEN - set a token before pairing a phone.")
    try: srv.serve_forever()
    except KeyboardInterrupt: print("\nBye.")


if __name__ == "__main__":
    main()
