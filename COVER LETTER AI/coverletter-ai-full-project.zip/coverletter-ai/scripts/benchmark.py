"""Measure the local pipeline on a large synthetic profile. Usage: python scripts/benchmark.py [projects=60]"""
import statistics, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from coverletter_ai.config import Settings
from coverletter_ai.evidence import build_evidence
from coverletter_ai.service import App

n = int(sys.argv[1]) if len(sys.argv) > 1 else 60
TOOLS = ["Python", "SQL", "Power BI", "Excel", "Tableau", "Docker", "Git", "Django", "Pandas", "Java", "React"]
resume = "# Bench Person\nbench@example.com\n## Skills\nPython, SQL, Excel, Power BI, Git\n## Projects\n"
for i in range(n):
    t = TOOLS[i % len(TOOLS)]
    resume += f"Project {i} {t} Study\n- Built a {t} workflow number {i} that analysed regional sales data and produced weekly reports.\n- Improved the {t} pipeline for team {i} using {TOOLS[(i + 3) % len(TOOLS)]}.\n"
job = "Data Analyst\nCompany: Bench Co\nResponsibilities:\n- Build dashboards and reports\n- Write SQL queries to analyse sales data\n- Automate recurring reporting\nRequirements:\n- Python, SQL, Power BI, Excel, Git, Docker\nNice to have:\n- Tableau\n"

def t(fn, *a, rep=1):
    ts = []
    for _ in range(rep):
        s = time.perf_counter(); out = fn(*a); ts.append((time.perf_counter() - s) * 1000)
    return out, statistics.median(ts)

app = App(Settings(data_dir=Path(tempfile.mkdtemp()), offline=True))
c, ms_import = t(app.create_candidate, "bench.md", resume.encode()); cid = c["id"]
j, ms_job = t(app.analyze_job, cid, job)
cand, jobd = app._cand(cid), app._job(j["job_id"])
_, cold = t(lambda: (app.rag.invalidate(cid), build_evidence(app.rag, cand, jobd, jobd["company_info"]))[1])
_, warm = t(build_evidence, app.rag, cand, jobd, jobd["company_info"], rep=7)
_, ms_gen = t(app.generate, cid, j["job_id"], {"force": True}, rep=5)
_, ms_hit = t(app.generate, cid, j["job_id"], None, rep=5)
_, ms_search = t(app.rag.search, cid, "power bi dashboard reporting", 8, rep=50)
_, ms_reidx = t(app.update_profile, cid, {"summary": "x"})
lid = app.generate(cid, j["job_id"])["letter_id"]
exp = {f: t(app.export, lid, f, rep=5)[1] for f in ("pdf", "docx", "odt", "rtf", "html", "txt", "zip")}
print(f"profile: {n} projects -> {len(app.rag.active_chunks(cid))} indexed chunks")
print(f"import + parse + index   : {ms_import:8.1f} ms")
print(f"job analysis             : {ms_job:8.1f} ms")
print(f"evidence build (cold)    : {cold:8.1f} ms   (index prepared)")
print(f"evidence build (cached)  : {warm:8.1f} ms   ({cold / warm:.1f}x faster)")
print(f"retrieval query          : {ms_search:8.2f} ms")
print(f"generate (template, full): {ms_gen:8.1f} ms   (evidence + compose + claim check + QA + save)")
print(f"generate (cache hit)     : {ms_hit:8.1f} ms")
print(f"profile edit re-index    : {ms_reidx:8.1f} ms   (incremental: only changed chunks re-embedded)")
print("export ms                : " + ", ".join(f"{k} {v:.1f}" for k, v in exp.items()))
