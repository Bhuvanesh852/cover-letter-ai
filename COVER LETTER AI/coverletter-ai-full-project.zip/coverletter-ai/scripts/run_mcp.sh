#!/usr/bin/env bash
# Remote connector: web UI + /mcp endpoint on loopback, protected by a token. Put a tunnel/reverse proxy in front for claude.ai.
set -e
cd "$(dirname "$0")/../backend"
export COVERLETTER_TOKEN="${COVERLETTER_TOKEN:-$(python3 -c 'import secrets;print(secrets.token_urlsafe(32))')}"
echo "MCP URL path:  /mcp/$COVERLETTER_TOKEN      (keep this secret)"
exec python3 -m coverletter_ai
