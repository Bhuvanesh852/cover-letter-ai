#!/usr/bin/env bash
# Required acceptance test: the whole import -> generate -> validate -> export flow with the network guard ON.
set -e
cd "$(dirname "$0")/../backend"
python3 -m unittest tests.test_core.Acceptance.test_end_to_end_offline_demo tests.test_core.Safety -v
python3 -m unittest tests.test_providers tests.test_mcp 2>&1 | tail -5
