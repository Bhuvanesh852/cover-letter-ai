# Use CoverLetter AI as a Claude connector (MCP)

The app includes an **MCP server** (`mcp_server.py`) with 16 tools. Claude can then run the whole job-application workflow for you:
*import resume → analyze job → get the evidence pack → write the letter → check every claim → save → export / email / interview prep → track the application.*

**Claude is the writer; CoverLetter AI is the fact-checker.** Claude writes from `get_evidence_pack`, then `check_claims` / `save_letter` strip anything the resume does not support (invented skills, employers, metrics, years, company facts). You need **no extra API key** - your Claude subscription does the writing.

> Not to be confused with `mcp.py`, which is the app's *outgoing* connector router (company-page fetching). `mcp_server.py` is the *incoming* server Claude talks to.

## Option A - Claude Desktop (local, most private) ✅ recommended
Runs as a local subprocess over stdio. Nothing is exposed to the network.

1. Edit Claude Desktop's config (Settings → Developer → Edit Config; `claude_desktop_config.json`; macOS: `~/Library/Application Support/Claude/`, Windows: `%APPDATA%\Claude\`).
2. Merge in `config/claude_desktop_config.example.json`, replacing `/ABSOLUTE/PATH/TO` with the real path (Windows: use `python` or `py` as `command`, and `\\` or `/` in paths).
3. Restart Claude Desktop. The tools appear under the connectors/tools menu. Try the **cover_letter_workflow** prompt, or say: *"Here's my resume … and this job … write me a cover letter."*
4. Resume files: put them in `storage/imports/` and say "import cv.pdf" (only that folder is readable). Pasting text also works.
5. Exports are returned inline (TXT/MD/HTML/JSON) or saved to `storage/exports/` (DOCX/PDF/ODT/RTF/ZIP).

## Option B - claude.ai custom connector (remote)
claude.ai connects to **remote** MCP servers over HTTPS, so your server must be reachable from the internet. (Custom-connector availability depends on your plan - check Claude's current docs.)

```bash
scripts/run_mcp.sh                       # prints  /mcp/<secret-token>   (server stays on 127.0.0.1)
cloudflared tunnel --url http://127.0.0.1:8787     # or ngrok / your own reverse proxy -> gives https://<name>.trycloudflare.com
```
In Claude: **Settings → Connectors → Add custom connector** → URL `https://<name>.trycloudflare.com/mcp/<secret-token>`.

**Read before using remote mode**
- The token is in the URL because the connector form only takes a URL. Treat the URL as a password: don't share or screenshot it; rotate by restarting with a new `COVERLETTER_TOKEN`. Clients that can send headers may use `Authorization: Bearer <token>` instead.
- Remote mode is **not** "data never leaves your machine": resume evidence passes through the tunnel and into your Claude conversation. For strict privacy use Option A.
- Quick tunnels change URL on restart; use a named tunnel or your own domain for something permanent.
- Anyone selling this to others should replace the shared token with **OAuth** (what claude.ai connectors natively use) - not included.
- The server refuses `/mcp` on a non-loopback bind without a token, checks the `Origin` header (claude.ai/claude.com/localhost allowed; add hosts with `MCP_ALLOWED_ORIGINS`), and rate-limits requests.

## What Claude can and cannot do
| Can | Cannot (by design) |
|---|---|
| Read profile summaries (no email/phone), analyze jobs, fetch the evidence pack | Turn the network on/off, change AI providers, read or set API keys |
| Save/validate/rewrite/export letters, draft emails, interview prep, tracker | Use outgoing web connectors, delete all data |
| Delete one profile (only with `confirm="DELETE"`, after you ask) | Read files outside `storage/imports/` |

Job descriptions are untrusted: injection attempts are screened and reported in `warnings`, and Claude is instructed to treat them as data. Claude will ask you to approve tool calls - avoid "always allow" for `delete_profile`.

## Troubleshooting
- Tools don't appear → check the absolute paths, run `python3 -m coverletter_ai.mcp_stdio` by hand (it should print `MCP stdio ready` on stderr), restart Claude Desktop.
- 401 on remote → token missing/wrong; 403 → Origin not allowed.
- "Every sentence was unsupported" → the draft did not use the evidence pack; ask Claude to write from `get_evidence_pack`.
- Verified against this repo's test suite (JSON-RPC handshake, all tools, HTTP + stdio transports). **Not yet tested against the live Claude apps** - the protocol surface follows the public MCP spec, but report any client-specific quirks.
