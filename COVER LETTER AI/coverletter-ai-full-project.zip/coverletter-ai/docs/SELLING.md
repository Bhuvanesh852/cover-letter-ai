# Selling CoverLetter AI - practical guide (not legal advice)

## What you actually have to sell
- **Private by default** (local data, offline-capable) - rare in this category and a genuine differentiator.
- **Grounded letters**: every sentence traced to the user's own resume; unsupported claims removed. Position it as *"won't invent experience for you"*.
- **Works with a free tier or no key at all** (template/local engine; optional Gemini / OpenRouter / etc.).
- **Claude connector**: users with Claude get an automated, fact-checked workflow without a second AI bill.
- 8 export formats, batch mode, tracker, interview prep.

## Packaging options (pick one to start)
| Option | Effort | Notes |
|---|---|---|
| Source + install guide (pay for support/updates) | Low | Python is readable; sell convenience, updates and support, not secrecy. |
| Desktop bundle (PyInstaller / installer) | Medium | Best for non-technical buyers. *Not built or tested here.* |
| Claude Desktop extension bundle | Medium | One-click install for Claude users; check Anthropic's current extension format docs. |
| Docker self-host | Low | Included; fine for technical buyers/teams. |
| Hosted SaaS | High | Changes the privacy story: you become a data processor. Needs OAuth, DPA, security review, backups, support. |

## Licensing - be realistic
Client-side license keys on readable Python only deter casual sharing. Don't build your business on DRM: charge for **updates, support, templates/skill packs, and hosted convenience**. If you still want keys, use signed licenses verified with an asymmetric public key (e.g. the `cryptography` package) - not implemented here.

## Pricing sketch (test it - these are guesses)
Free: template engine, TXT/MD export · Pro (one-time or ~monthly): cloud engines, all formats, batch, Claude connector, updates · Team/Career-centre: multi-profile, branding, support.

## Compliance & trust checklist
- **Names/trademarks**: don't put "Claude", "Gemini", "OpenAI" etc. in the product name or imply endorsement; "works with Claude" is the safe phrasing. Check each vendor's brand rules.
- **Provider terms**: users bring their **own** keys. Don't ship your key, don't proxy/resell other people's free tiers, and warn that free tiers may use inputs for model improvement (already in the UI).
- **Personal data**: resumes are personal data. Publish a privacy policy that matches reality (local storage, optional cloud/Claude transit, no telemetry). Depending on where buyers live, GDPR / India DPDP / CCPA-type rules may apply - get a lawyer's review before launch.
- **Payments & tax**: a merchant-of-record (Lemon Squeezy, Paddle, Gumroad) handles VAT/GST for you; Stripe/Razorpay give more control but more admin.
- **Terms/EULA, refund policy, AI disclaimer**: letters must be reviewed by the user; no guarantee of interviews, ATS results or jobs. Never market "beats ATS" or "guaranteed".
- **Third-party licences**: the core uses only the Python standard library (optional pypdf/reportlab have their own licences - check before bundling).

## Before the first paying customer
1. Test **Ollama and every cloud provider with real keys** (only fake servers were used so far).
2. Test the connector in **real Claude Desktop and claude.ai** and fix client quirks.
3. Add OAuth if offering a remote connector to others; security review of the HTTP surface.
4. Broaden the skill lexicon (`knowledge.py`) for your target job fields; consider a bigger local embedding model.
5. Add crash-safe backups/export of the user's data; decide on opt-in telemetry (default off).
6. Set up support, a changelog, and an update path.
