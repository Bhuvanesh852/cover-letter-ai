# CoverLetter AI — Offline Job Application Copilot

Generate a job-specific cover letter from **your own verified experience** — privately, on your machine, with no paid API.

The core idea is a hard rule enforced in code, not just in a prompt:

> **Truth > Personalization > Style.** Every sentence is classified as `VERIFIED`, `SUPPORTED_INFERENCE`, `GENERAL_PROFESSIONAL_LANGUAGE` or `UNSUPPORTED`. Unsupported sentences are removed before you ever see the letter.

## Run it (no installs required for the core)

```bash
cd backend
python3 -m coverletter_ai            # http://127.0.0.1:8787
```
Open the URL, click **Load demo** (synthetic data), then **Analyze & generate**.
Optional: `pip install -r requirements.txt` (only needed to *import* PDF resumes).

**Tests:** `cd backend && python -m unittest discover -s tests -v` (also runs under `pytest`).

## AI engines: offline, online, or both
Pick the engine in **AI engine** tab. Everything works with **no API key**.

| Engine | Needs key? | Network | Notes |
|---|---|---|---|
| **Template engine** (default) | No | None | Deterministic composer built from your retrieved evidence. Not an LLM; plainer but always safe. |
| **Local SLM** via [Ollama](https://ollama.com) | No | Loopback only | Install Ollama + any instruction-tuned model, set `OLLAMA_MODEL`. |
| **Custom local server** (LM Studio, llama.cpp, vLLM) | Optional | Loopback | OpenAI-compatible; stays on your machine. |
| **Google Gemini** · **OpenRouter** · **Groq** · **OpenAI** · **xAI Grok** · **Anthropic** · **Mistral** · **DeepSeek** | Your own key | Internet | Free tiers exist for some (Gemini Flash, OpenRouter `:free` models, others at times) and change often. |

**How cloud use is controlled**
1. Cloud runs only when **the network switch is ON**, **you approved that provider**, and a key + model exist. Otherwise the app uses the local engine and tells you why (or, with fallback off, stops with a clear message).
2. **Preview what will be sent** shows the exact prompt. Only selected evidence snippets, your name, skills, job and company text leave the machine - never the full resume, email, phone, links or other profiles.
3. Keys: environment variables first, then session memory, optionally a `0600` file. Sent only in auth headers (never URLs), never logged, never returned by the API (masked tail only).
4. **Cloud output gets the same claim checker as everything else** - invented skills, employers, numbers and company facts are removed before you see the letter (tested with a hallucinating fake provider).
5. Models are listed live from the provider (**List models**, with a *free only* filter for OpenRouter) because model names and free tiers change often. **Free tiers may allow the provider to use your inputs to improve its models** (documented for Gemini's free tier) - avoid them for anything you would not want reviewed. Check each provider's current terms.

## Export formats
**PDF, DOCX, ODT, RTF, HTML, TXT, Markdown, JSON, and an all-in-one ZIP** - all generated without any pip package (DOCX/ODT/RTF/PDF verified to open in LibreOffice; `reportlab` is used for PDF only if installed). **Copy text** and TXT/MD/JSON work with no key and no network. `POST /api/convert/text` turns an uploaded PDF/DOCX/MD into plain text.

## Extras
Email draft (subject + body, no invented names) · interview prep questions built from your evidence (gaps are labelled "be honest") · compare formal / standard / technical styles · **batch mode** (up to 25 jobs → one ZIP) · result cache · evidence overrides (use / do-not-use per snippet).

## Performance (measured, `python scripts/benchmark.py 300`)
302 indexed chunks on a laptop-class sandbox: import+index 119 ms · evidence build 22 ms cold → 8.6 ms cached · retrieval query 1 ms · full template generation 24 ms · cache hit 9 ms · profile edit re-index 3 ms (incremental). In practice the *model call* dominates (seconds for a local SLM or cloud API); the repeat-generation cache skips it entirely.

## Use it from Claude (MCP connector)
`python -m coverletter_ai.mcp_stdio` (Claude Desktop, local) or `POST /mcp/<token>` (remote, e.g. claude.ai custom connector). Claude gets 16 tools and writes the letter from the evidence pack; the app verifies every claim and removes unsupported ones - **no extra API key needed**. Network/keys/privacy settings are deliberately *not* exposed to the model. Setup, security notes and limits: [`docs/CLAUDE_CONNECTOR.md`](docs/CLAUDE_CONNECTOR.md). Selling it: [`docs/SELLING.md`](docs/SELLING.md).

## Architecture
```
resume ─► parser ─► profile ─► chunks(+metadata) ─► local index (hashing embeddings + BM25, hybrid-fused)
job text ─► injection screen ─► requirement parser ─┐
company notes (user-provided) ──────────────────────┤
                                                    ▼
                          evidence matrix + evidence pack (allowed / prohibited claims)
                                                    ▼
                   provider: Ollama SLM  |  template composer   ──► draft
                                                    ▼
        claim validator ─► (SLM revise pass) ─► sanitize (drop unsupported) ─► style/ATS QA
                                                    ▼
                     versioned letter + per-sentence evidence trace ─► edit · rewrite · export
```
| Module | Responsibility |
|---|---|
| `parsing.py`, `profile.py` | PDF/DOCX/TXT/MD → text → structured profile, parse-quality reporting |
| `jobs.py` | JD parsing, required/preferred split, noise cleanup, **prompt-injection screening** |
| `rag.py` | Semantic chunking, per-candidate isolation, incremental re-indexing, hybrid retrieval |
| `evidence.py` | Requirement ↔ evidence matrix (strong / partial / not found), evidence pack |
| `generator.py`, `llm.py`, `cloud.py` | Prompt with data delimiters, Ollama + cloud adapters (OpenAI-compatible / Gemini / Anthropic), key store, validate→revise loop |
| `mcp_server.py`, `mcp_stdio.py` | Incoming MCP server (JSON-RPC 2.0): 16 annotated tools, workflow prompt, stdio + Streamable HTTP, auth/Origin checks |
| `aisvc.py` | AI settings, consent/offline gating, local fallback, result cache, extras (email, interview, variants, batch) |
| `validator.py` | Claim control: unsupported skills, numbers, years, titles, leadership, inflated wording, unknown names, unsourced company claims |
| `mcp.py` | *Outgoing* connector registry, DENY/ASK/ALLOW, schema validation, SSRF guard, HTML cleaning, audit |
| `netguard.py` | Network kill switch that makes "no outbound calls when offline" testable |
| `exporter.py` | 8 formats + ZIP, stdlib-only writers (ATS-friendly, selectable text) |
| `service.py`, `server.py` | Application service + stdlib HTTP API and web UI |

## Privacy & security
- Local SQLite (`storage/`), bound to `127.0.0.1`, no telemetry, HTTP keep-alive with drained bodies, logs contain IDs/status only — never resume or letter text.
- **Offline by default.** The header switch turns the network on; connectors default to `ASK`; resume data is never sent to a connector.
- Retrieved/pasted documents are **data, not instructions**: injection lines are dropped, tag-like text is escaped, and model output is validated regardless.
- Delete one profile or everything (cascades to chunks, embeddings, jobs, letters, applications; `secure_delete` + `VACUUM`).
- Optional bearer token (`COVERLETTER_TOKEN`), request-size limits, rate limiting, path-traversal-safe static serving, CSP headers.

| Threat | Mitigation |
|---|---|
| Malicious document / injection | Screening, delimiters, post-generation validator |
| Unauthorised tool use | Allowlist, schema validation, permissions, kill switch, audit |
| Data leakage | Loopback bind, no uploads in offline mode, tested by `netguard` |
| Cross-profile retrieval | `candidate_id` filter in every query (tested) |
| SSRF via web connector | http(s) only, private/loopback IPs rejected |
| Zip bombs / huge files | Size limits, decompressed-size check |

## Honest limits (v1.0)
- **Validation is rule-based.** It reliably blocks the failure modes in the test-suite (fake skills, employers, metrics, years, leadership, company claims) but it is not a proof of truthfulness — always read the letter. Uncertain cases surface as *Needs review*.
- Skill detection uses a built-in lexicon (~55 skills). Extend `knowledge.py` for your field.
- The default embedder is lexical-semantic hashing; plug any local embedding model into `RagStore(embedder=…)`.
- **Ollama and the cloud adapters were not exercised against live services in the build environment** (no network). They are tested against local fake servers that mimic the OpenAI-compatible, Gemini and Anthropic wire formats; request shapes follow each provider's public API, but a first real call may need a model-name tweak - use *List models* and *Test*.
- Free-tier limits and model names are provider-controlled and change; the app never hard-codes them beyond editable suggestions.
- Keys saved with *remember* are an owner-only plain file, not encrypted.
- Not yet built: mobile app, streaming UI, OCR, voice, encrypted backup, billing adapter. The service layer is UI-agnostic so a React Native client can use the same HTTP API (set a token and bind to your LAN).
- Alignment numbers are informational. They do not predict hiring outcomes.

## API (JSON over HTTP)
`GET|POST /api/ai` · `GET /api/ai/models` · `POST /api/ai/test|preview` · `POST /api/letters/variants|{id}/email` · `GET /api/jobs/{id}/interview` · `POST /api/batch` · `POST /api/batch/export` · `POST /api/convert/text` · `GET /api/health` · `POST /api/candidates` · `PUT /api/candidates/{id}/profile` · `POST /api/candidates/{id}/evidence` · `PATCH /api/chunks/{id}` (use / do_not_use) · `POST /api/jobs/analyze` · `POST /api/letters/generate` · `POST /api/letters/{id}/validate|save|rewrite` · `GET /api/letters/{id}/export?format=pdf|docx|odt|rtf|html|txt|md|json|zip` · `GET|POST /api/applications` · `GET /api/mcp/servers` · `POST /api/mcp/permission|call` · `POST /api/settings/network` · `GET /api/audit` · `DELETE /api/candidates/{id}` · `POST /api/data/delete_all`

## Docker (optional)
`COVERLETTER_TOKEN=change-me docker compose up --build`
