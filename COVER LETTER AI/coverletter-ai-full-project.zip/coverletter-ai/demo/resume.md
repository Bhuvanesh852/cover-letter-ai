# Demo Candidate
demo.candidate@example.com | +91 90000 00000

SYNTHETIC DEMO DATA - not a real person.

## Summary
Junior data analyst with a computer science degree and hands-on project work in reporting and dashboards.

## Skills
Programming: Python, SQL
Tools: Excel, Power BI

## Projects
Sales Analysis Dashboard
- Built a Power BI dashboard tracking regional sales performance using SQL queries.
- Automated weekly reporting with Python scripts.
HR Analytics
- Analysed employee attrition data in Excel to identify the main drivers of turnover.

## Education
B.Sc Computer Science, Example University, 2024

## Certifications
Google Data Analytics Certificate
