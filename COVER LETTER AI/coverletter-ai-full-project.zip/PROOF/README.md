# Proof of testing — CoverLetter AI v1.0.0
Captured 2026-10-03 on the real running app (`python -m coverletter_ai`), offline mode, Python 3.12, with a synthetic candidate typed in (not the built-in demo).

| File | What it proves |
|---|---|
| proof_1_of_5.png | A pasted resume is imported; skills, projects, education detected |
| proof_2_of_5.png | A pasted job is analysed; requirements mapped to evidence (strong / partial / not found) |
| proof_3_of_5.png | A cover letter is generated, passes the grounding check, and each sentence traces to a resume item |
| proof_4_of_5.png | Fake claims (AWS, Google, 15 engineers, +40%) injected → flagged "Needs review" → removed → "Passed" |
| proof_5_of_5.png | The exported PDF renders; all 9 exports were downloaded and their contents verified |
| test_output.txt | Full automated test run: 40 tests, OK |

## What the proof does NOT show
- The letter was written by the built-in **template engine** (no language model is installed here). Local-model (Ollama) and cloud-provider engines (Gemini, OpenRouter, OpenAI, …) were not run against live services; they are tested only against simulated servers.
- The claim checker is rule-based. Known miss seen in this run: the resume's "weekly sales **report**" did not match the requirement "reporting" (the skill list matches "reporting/reports" but not the singular), so the matrix under-reported that requirement. Errors like this are conservative (it under-claims) but real.

## Reproduce
`cd backend && python3 -m unittest discover -s tests -v` → `OK`; then `python3 -m coverletter_ai`, open http://127.0.0.1:8787, paste a resume, paste a job, **Analyze & generate**; in the letter click **Edit**, add a fake claim, **Save & validate**, then **Remove unsupported**.
